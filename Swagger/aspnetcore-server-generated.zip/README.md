# Bps.uCloud.API - ASP.NET Core 2.0 Server

uCloud is a collection of image APIs.

## Run

Linux/OS X:

```
sh build.sh
```

Windows:

```
build.bat
```

## Run in Docker

```
cd src/Bps.uCloud.API
docker build -t bps.ucloud.api .
docker run -p 5000:5000 bps.ucloud.api
```
