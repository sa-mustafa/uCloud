using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Sharpility.Extensions;
using NodaTime;

namespace IO.Swagger.sa_mustafaucloudv1.Models
{
    /// <summary>
    /// SampleImage
    /// </summary>
    public sealed class SampleImage:  IEquatable<SampleImage>
    { 
        /// <summary>
        /// Id
        /// </summary>
        public string Id { get; private set; }

        /// <summary>
        /// Index
        /// </summary>
        public string Index { get; private set; }

        /// <summary>
        /// Name
        /// </summary>
        public string Name { get; private set; }


        /// <summary>
        /// Empty constructor required by some serializers.
        /// Use SampleImage.Builder() for instance creation instead.
        /// </summary>
        [Obsolete]
        public SampleImage()
        {
        }

        private SampleImage(string Id, string Index, string Name)
        {
            
            this.Id = Id;
            
            this.Index = Index;
            
            this.Name = Name;
            
        }

        /// <summary>
        /// Returns builder of SampleImage.
        /// </summary>
        /// <returns>SampleImageBuilder</returns>
        public static SampleImageBuilder Builder()
        {
            return new SampleImageBuilder();
        }

        /// <summary>
        /// Returns SampleImageBuilder with properties set.
        /// Use it to change properties.
        /// </summary>
        /// <returns>SampleImageBuilder</returns>
        public SampleImageBuilder With()
        {
            return Builder()
                .Id(Id)
                .Index(Index)
                .Name(Name);
        }

        public override string ToString()
        {
            return this.PropertiesToString();
        }

        public override bool Equals(object obj)
        {
            return this.EqualsByProperties(obj);
        }

        public bool Equals(SampleImage other)
        {
            return Equals((object) other);
        }

        public override int GetHashCode()
        {
            return this.PropertiesHash();
        }

        /// <summary>
        /// Implementation of == operator for (SampleImage.
        /// </summary>
        /// <param name="left">Compared (SampleImage</param>
        /// <param name="right">Compared (SampleImage</param>
        /// <returns>true if compared items are equals, false otherwise</returns>
        public static bool operator == (SampleImage left, SampleImage right)
        {
            return Equals(left, right);
        }

        /// <summary>
        /// Implementation of != operator for (SampleImage.
        /// </summary>
        /// <param name="left">Compared (SampleImage</param>
        /// <param name="right">Compared (SampleImage</param>
        /// <returns>true if compared items are not equals, false otherwise</returns>
        public static bool operator != (SampleImage left, SampleImage right)
        {
            return !Equals(left, right);
        }

        /// <summary>
        /// Builder of SampleImage.
        /// </summary>
        public sealed class SampleImageBuilder
        {
            private string _Id;
            private string _Index;
            private string _Name;

            internal SampleImageBuilder()
            {
                SetupDefaults();
            }

            private void SetupDefaults()
            {
            }

            /// <summary>
            /// Sets value for SampleImage.Id property.
            /// </summary>
            /// <param name="value">Id</param>
            public SampleImageBuilder Id(string value)
            {
                _Id = value;
                return this;
            }

            /// <summary>
            /// Sets value for SampleImage.Index property.
            /// </summary>
            /// <param name="value">Index</param>
            public SampleImageBuilder Index(string value)
            {
                _Index = value;
                return this;
            }

            /// <summary>
            /// Sets value for SampleImage.Name property.
            /// </summary>
            /// <param name="value">Name</param>
            public SampleImageBuilder Name(string value)
            {
                _Name = value;
                return this;
            }


            /// <summary>
            /// Builds instance of SampleImage.
            /// </summary>
            /// <returns>SampleImage</returns>
            public SampleImage Build()
            {
                Validate();
                return new SampleImage(
                    Id: _Id,
                    Index: _Index,
                    Name: _Name
                );
            }

            private void Validate()
            { 
            }
        }

        
    }
}