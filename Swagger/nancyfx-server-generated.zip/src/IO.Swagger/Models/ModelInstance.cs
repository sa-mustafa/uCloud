using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Sharpility.Extensions;
using NodaTime;

namespace IO.Swagger.sa_mustafaucloudv1.Models
{
    /// <summary>
    /// ModelInstance
    /// </summary>
    public sealed class ModelInstance:  IEquatable<ModelInstance>
    { 
        /// <summary>
        /// rotation angles of found instances of the model; applies to all except deformable/descriptor/perspective matchers.
        /// </summary>
        public List<float?> Angles { get; private set; }

        /// <summary>
        /// rows of found instances of the model; applies to all except descriptor/perspective matchers.
        /// </summary>
        public List<float?> Cols { get; private set; }

        /// <summary>
        /// columns of found instances of the model; applies to all except descriptor/perspective matchers.
        /// </summary>
        public List<float?> Rows { get; private set; }

        /// <summary>
        /// scales of found instances; applies to isotropic matcher only.
        /// </summary>
        public List<float?> Scales { get; private set; }

        /// <summary>
        /// scales of found instances in row direction; applies to anisotropic matcher only.
        /// </summary>
        public List<float?> ScalesRow { get; private set; }

        /// <summary>
        /// scales of found instances in column direction; applies to anisotropic matcher only.
        /// </summary>
        public List<float?> ScalesCol { get; private set; }

        /// <summary>
        /// homography transforms between found instances and the model; applies to descriptor &amp; perspective matchers only.
        /// </summary>
        public List<float?> Transforms { get; private set; }

        /// <summary>
        /// matching scores of found instances.
        /// </summary>
        public List<float?> Scores { get; private set; }


        /// <summary>
        /// Empty constructor required by some serializers.
        /// Use ModelInstance.Builder() for instance creation instead.
        /// </summary>
        [Obsolete]
        public ModelInstance()
        {
        }

        private ModelInstance(List<float?> Angles, List<float?> Cols, List<float?> Rows, List<float?> Scales, List<float?> ScalesRow, List<float?> ScalesCol, List<float?> Transforms, List<float?> Scores)
        {
            
            this.Angles = Angles;
            
            this.Cols = Cols;
            
            this.Rows = Rows;
            
            this.Scales = Scales;
            
            this.ScalesRow = ScalesRow;
            
            this.ScalesCol = ScalesCol;
            
            this.Transforms = Transforms;
            
            this.Scores = Scores;
            
        }

        /// <summary>
        /// Returns builder of ModelInstance.
        /// </summary>
        /// <returns>ModelInstanceBuilder</returns>
        public static ModelInstanceBuilder Builder()
        {
            return new ModelInstanceBuilder();
        }

        /// <summary>
        /// Returns ModelInstanceBuilder with properties set.
        /// Use it to change properties.
        /// </summary>
        /// <returns>ModelInstanceBuilder</returns>
        public ModelInstanceBuilder With()
        {
            return Builder()
                .Angles(Angles)
                .Cols(Cols)
                .Rows(Rows)
                .Scales(Scales)
                .ScalesRow(ScalesRow)
                .ScalesCol(ScalesCol)
                .Transforms(Transforms)
                .Scores(Scores);
        }

        public override string ToString()
        {
            return this.PropertiesToString();
        }

        public override bool Equals(object obj)
        {
            return this.EqualsByProperties(obj);
        }

        public bool Equals(ModelInstance other)
        {
            return Equals((object) other);
        }

        public override int GetHashCode()
        {
            return this.PropertiesHash();
        }

        /// <summary>
        /// Implementation of == operator for (ModelInstance.
        /// </summary>
        /// <param name="left">Compared (ModelInstance</param>
        /// <param name="right">Compared (ModelInstance</param>
        /// <returns>true if compared items are equals, false otherwise</returns>
        public static bool operator == (ModelInstance left, ModelInstance right)
        {
            return Equals(left, right);
        }

        /// <summary>
        /// Implementation of != operator for (ModelInstance.
        /// </summary>
        /// <param name="left">Compared (ModelInstance</param>
        /// <param name="right">Compared (ModelInstance</param>
        /// <returns>true if compared items are not equals, false otherwise</returns>
        public static bool operator != (ModelInstance left, ModelInstance right)
        {
            return !Equals(left, right);
        }

        /// <summary>
        /// Builder of ModelInstance.
        /// </summary>
        public sealed class ModelInstanceBuilder
        {
            private List<float?> _Angles;
            private List<float?> _Cols;
            private List<float?> _Rows;
            private List<float?> _Scales;
            private List<float?> _ScalesRow;
            private List<float?> _ScalesCol;
            private List<float?> _Transforms;
            private List<float?> _Scores;

            internal ModelInstanceBuilder()
            {
                SetupDefaults();
            }

            private void SetupDefaults()
            {
            }

            /// <summary>
            /// Sets value for ModelInstance.Angles property.
            /// </summary>
            /// <param name="value">rotation angles of found instances of the model; applies to all except deformable/descriptor/perspective matchers.</param>
            public ModelInstanceBuilder Angles(List<float?> value)
            {
                _Angles = value;
                return this;
            }

            /// <summary>
            /// Sets value for ModelInstance.Cols property.
            /// </summary>
            /// <param name="value">rows of found instances of the model; applies to all except descriptor/perspective matchers.</param>
            public ModelInstanceBuilder Cols(List<float?> value)
            {
                _Cols = value;
                return this;
            }

            /// <summary>
            /// Sets value for ModelInstance.Rows property.
            /// </summary>
            /// <param name="value">columns of found instances of the model; applies to all except descriptor/perspective matchers.</param>
            public ModelInstanceBuilder Rows(List<float?> value)
            {
                _Rows = value;
                return this;
            }

            /// <summary>
            /// Sets value for ModelInstance.Scales property.
            /// </summary>
            /// <param name="value">scales of found instances; applies to isotropic matcher only.</param>
            public ModelInstanceBuilder Scales(List<float?> value)
            {
                _Scales = value;
                return this;
            }

            /// <summary>
            /// Sets value for ModelInstance.ScalesRow property.
            /// </summary>
            /// <param name="value">scales of found instances in row direction; applies to anisotropic matcher only.</param>
            public ModelInstanceBuilder ScalesRow(List<float?> value)
            {
                _ScalesRow = value;
                return this;
            }

            /// <summary>
            /// Sets value for ModelInstance.ScalesCol property.
            /// </summary>
            /// <param name="value">scales of found instances in column direction; applies to anisotropic matcher only.</param>
            public ModelInstanceBuilder ScalesCol(List<float?> value)
            {
                _ScalesCol = value;
                return this;
            }

            /// <summary>
            /// Sets value for ModelInstance.Transforms property.
            /// </summary>
            /// <param name="value">homography transforms between found instances and the model; applies to descriptor &amp; perspective matchers only.</param>
            public ModelInstanceBuilder Transforms(List<float?> value)
            {
                _Transforms = value;
                return this;
            }

            /// <summary>
            /// Sets value for ModelInstance.Scores property.
            /// </summary>
            /// <param name="value">matching scores of found instances.</param>
            public ModelInstanceBuilder Scores(List<float?> value)
            {
                _Scores = value;
                return this;
            }


            /// <summary>
            /// Builds instance of ModelInstance.
            /// </summary>
            /// <returns>ModelInstance</returns>
            public ModelInstance Build()
            {
                Validate();
                return new ModelInstance(
                    Angles: _Angles,
                    Cols: _Cols,
                    Rows: _Rows,
                    Scales: _Scales,
                    ScalesRow: _ScalesRow,
                    ScalesCol: _ScalesCol,
                    Transforms: _Transforms,
                    Scores: _Scores
                );
            }

            private void Validate()
            { 
            }
        }

        
    }
}