using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Sharpility.Extensions;
using NodaTime;

namespace IO.Swagger.sa_mustafaucloudv1.Models
{
    /// <summary>
    /// Barcode
    /// </summary>
    public sealed class Barcode:  IEquatable<Barcode>
    { 
        /// <summary>
        /// Location
        /// </summary>
        public string Location { get; private set; }

        /// <summary>
        /// barcode data payload
        /// </summary>
        public string Data { get; private set; }

        /// <summary>
        /// Type
        /// </summary>
        public string Type { get; private set; }


        /// <summary>
        /// Empty constructor required by some serializers.
        /// Use Barcode.Builder() for instance creation instead.
        /// </summary>
        [Obsolete]
        public Barcode()
        {
        }

        private Barcode(string Location, string Data, string Type)
        {
            
            this.Location = Location;
            
            this.Data = Data;
            
            this.Type = Type;
            
        }

        /// <summary>
        /// Returns builder of Barcode.
        /// </summary>
        /// <returns>BarcodeBuilder</returns>
        public static BarcodeBuilder Builder()
        {
            return new BarcodeBuilder();
        }

        /// <summary>
        /// Returns BarcodeBuilder with properties set.
        /// Use it to change properties.
        /// </summary>
        /// <returns>BarcodeBuilder</returns>
        public BarcodeBuilder With()
        {
            return Builder()
                .Location(Location)
                .Data(Data)
                .Type(Type);
        }

        public override string ToString()
        {
            return this.PropertiesToString();
        }

        public override bool Equals(object obj)
        {
            return this.EqualsByProperties(obj);
        }

        public bool Equals(Barcode other)
        {
            return Equals((object) other);
        }

        public override int GetHashCode()
        {
            return this.PropertiesHash();
        }

        /// <summary>
        /// Implementation of == operator for (Barcode.
        /// </summary>
        /// <param name="left">Compared (Barcode</param>
        /// <param name="right">Compared (Barcode</param>
        /// <returns>true if compared items are equals, false otherwise</returns>
        public static bool operator == (Barcode left, Barcode right)
        {
            return Equals(left, right);
        }

        /// <summary>
        /// Implementation of != operator for (Barcode.
        /// </summary>
        /// <param name="left">Compared (Barcode</param>
        /// <param name="right">Compared (Barcode</param>
        /// <returns>true if compared items are not equals, false otherwise</returns>
        public static bool operator != (Barcode left, Barcode right)
        {
            return !Equals(left, right);
        }

        /// <summary>
        /// Builder of Barcode.
        /// </summary>
        public sealed class BarcodeBuilder
        {
            private string _Location;
            private string _Data;
            private string _Type;

            internal BarcodeBuilder()
            {
                SetupDefaults();
            }

            private void SetupDefaults()
            {
            }

            /// <summary>
            /// Sets value for Barcode.Location property.
            /// </summary>
            /// <param name="value">Location</param>
            public BarcodeBuilder Location(string value)
            {
                _Location = value;
                return this;
            }

            /// <summary>
            /// Sets value for Barcode.Data property.
            /// </summary>
            /// <param name="value">barcode data payload</param>
            public BarcodeBuilder Data(string value)
            {
                _Data = value;
                return this;
            }

            /// <summary>
            /// Sets value for Barcode.Type property.
            /// </summary>
            /// <param name="value">Type</param>
            public BarcodeBuilder Type(string value)
            {
                _Type = value;
                return this;
            }


            /// <summary>
            /// Builds instance of Barcode.
            /// </summary>
            /// <returns>Barcode</returns>
            public Barcode Build()
            {
                Validate();
                return new Barcode(
                    Location: _Location,
                    Data: _Data,
                    Type: _Type
                );
            }

            private void Validate()
            { 
            }
        }

        
    }
}