using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Sharpility.Extensions;
using NodaTime;

namespace IO.Swagger.sa_mustafaucloudv1.Models
{
    /// <summary>
    /// Image
    /// </summary>
    public sealed class Image:  IEquatable<Image>
    { 
        /// <summary>
        /// Id
        /// </summary>
        public string Id { get; private set; }

        /// <summary>
        /// Name
        /// </summary>
        public string Name { get; private set; }

        /// <summary>
        /// Tag
        /// </summary>
        public string Tag { get; private set; }

        /// <summary>
        /// Image URL or content in base64
        /// </summary>
        public string Source { get; private set; }

        /// <summary>
        /// Specify the image source type.
        /// </summary>
        public TypeEnum? Type { get; private set; }


        /// <summary>
        /// Empty constructor required by some serializers.
        /// Use Image.Builder() for instance creation instead.
        /// </summary>
        [Obsolete]
        public Image()
        {
        }

        private Image(string Id, string Name, string Tag, string Source, TypeEnum? Type)
        {
            
            this.Id = Id;
            
            this.Name = Name;
            
            this.Tag = Tag;
            
            this.Source = Source;
            
            this.Type = Type;
            
        }

        /// <summary>
        /// Returns builder of Image.
        /// </summary>
        /// <returns>ImageBuilder</returns>
        public static ImageBuilder Builder()
        {
            return new ImageBuilder();
        }

        /// <summary>
        /// Returns ImageBuilder with properties set.
        /// Use it to change properties.
        /// </summary>
        /// <returns>ImageBuilder</returns>
        public ImageBuilder With()
        {
            return Builder()
                .Id(Id)
                .Name(Name)
                .Tag(Tag)
                .Source(Source)
                .Type(Type);
        }

        public override string ToString()
        {
            return this.PropertiesToString();
        }

        public override bool Equals(object obj)
        {
            return this.EqualsByProperties(obj);
        }

        public bool Equals(Image other)
        {
            return Equals((object) other);
        }

        public override int GetHashCode()
        {
            return this.PropertiesHash();
        }

        /// <summary>
        /// Implementation of == operator for (Image.
        /// </summary>
        /// <param name="left">Compared (Image</param>
        /// <param name="right">Compared (Image</param>
        /// <returns>true if compared items are equals, false otherwise</returns>
        public static bool operator == (Image left, Image right)
        {
            return Equals(left, right);
        }

        /// <summary>
        /// Implementation of != operator for (Image.
        /// </summary>
        /// <param name="left">Compared (Image</param>
        /// <param name="right">Compared (Image</param>
        /// <returns>true if compared items are not equals, false otherwise</returns>
        public static bool operator != (Image left, Image right)
        {
            return !Equals(left, right);
        }

        /// <summary>
        /// Builder of Image.
        /// </summary>
        public sealed class ImageBuilder
        {
            private string _Id;
            private string _Name;
            private string _Tag;
            private string _Source;
            private TypeEnum? _Type;

            internal ImageBuilder()
            {
                SetupDefaults();
            }

            private void SetupDefaults()
            {
            }

            /// <summary>
            /// Sets value for Image.Id property.
            /// </summary>
            /// <param name="value">Id</param>
            public ImageBuilder Id(string value)
            {
                _Id = value;
                return this;
            }

            /// <summary>
            /// Sets value for Image.Name property.
            /// </summary>
            /// <param name="value">Name</param>
            public ImageBuilder Name(string value)
            {
                _Name = value;
                return this;
            }

            /// <summary>
            /// Sets value for Image.Tag property.
            /// </summary>
            /// <param name="value">Tag</param>
            public ImageBuilder Tag(string value)
            {
                _Tag = value;
                return this;
            }

            /// <summary>
            /// Sets value for Image.Source property.
            /// </summary>
            /// <param name="value">Image URL or content in base64</param>
            public ImageBuilder Source(string value)
            {
                _Source = value;
                return this;
            }

            /// <summary>
            /// Sets value for Image.Type property.
            /// </summary>
            /// <param name="value">Specify the image source type.</param>
            public ImageBuilder Type(TypeEnum? value)
            {
                _Type = value;
                return this;
            }


            /// <summary>
            /// Builds instance of Image.
            /// </summary>
            /// <returns>Image</returns>
            public Image Build()
            {
                Validate();
                return new Image(
                    Id: _Id,
                    Name: _Name,
                    Tag: _Tag,
                    Source: _Source,
                    Type: _Type
                );
            }

            private void Validate()
            { 
            }
        }

        
        public enum TypeEnum { Url, Base64 };
    }
}