using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Sharpility.Extensions;
using NodaTime;

namespace IO.Swagger.sa_mustafaucloudv1.Models
{
    /// <summary>
    /// Size
    /// </summary>
    public sealed class Size:  IEquatable<Size>
    { 
        /// <summary>
        /// Height
        /// </summary>
        public float? Height { get; private set; }

        /// <summary>
        /// Width
        /// </summary>
        public float? Width { get; private set; }


        /// <summary>
        /// Empty constructor required by some serializers.
        /// Use Size.Builder() for instance creation instead.
        /// </summary>
        [Obsolete]
        public Size()
        {
        }

        private Size(float? Height, float? Width)
        {
            
            this.Height = Height;
            
            this.Width = Width;
            
        }

        /// <summary>
        /// Returns builder of Size.
        /// </summary>
        /// <returns>SizeBuilder</returns>
        public static SizeBuilder Builder()
        {
            return new SizeBuilder();
        }

        /// <summary>
        /// Returns SizeBuilder with properties set.
        /// Use it to change properties.
        /// </summary>
        /// <returns>SizeBuilder</returns>
        public SizeBuilder With()
        {
            return Builder()
                .Height(Height)
                .Width(Width);
        }

        public override string ToString()
        {
            return this.PropertiesToString();
        }

        public override bool Equals(object obj)
        {
            return this.EqualsByProperties(obj);
        }

        public bool Equals(Size other)
        {
            return Equals((object) other);
        }

        public override int GetHashCode()
        {
            return this.PropertiesHash();
        }

        /// <summary>
        /// Implementation of == operator for (Size.
        /// </summary>
        /// <param name="left">Compared (Size</param>
        /// <param name="right">Compared (Size</param>
        /// <returns>true if compared items are equals, false otherwise</returns>
        public static bool operator == (Size left, Size right)
        {
            return Equals(left, right);
        }

        /// <summary>
        /// Implementation of != operator for (Size.
        /// </summary>
        /// <param name="left">Compared (Size</param>
        /// <param name="right">Compared (Size</param>
        /// <returns>true if compared items are not equals, false otherwise</returns>
        public static bool operator != (Size left, Size right)
        {
            return !Equals(left, right);
        }

        /// <summary>
        /// Builder of Size.
        /// </summary>
        public sealed class SizeBuilder
        {
            private float? _Height;
            private float? _Width;

            internal SizeBuilder()
            {
                SetupDefaults();
            }

            private void SetupDefaults()
            {
            }

            /// <summary>
            /// Sets value for Size.Height property.
            /// </summary>
            /// <param name="value">Height</param>
            public SizeBuilder Height(float? value)
            {
                _Height = value;
                return this;
            }

            /// <summary>
            /// Sets value for Size.Width property.
            /// </summary>
            /// <param name="value">Width</param>
            public SizeBuilder Width(float? value)
            {
                _Width = value;
                return this;
            }


            /// <summary>
            /// Builds instance of Size.
            /// </summary>
            /// <returns>Size</returns>
            public Size Build()
            {
                Validate();
                return new Size(
                    Height: _Height,
                    Width: _Width
                );
            }

            private void Validate()
            { 
            }
        }

        
    }
}