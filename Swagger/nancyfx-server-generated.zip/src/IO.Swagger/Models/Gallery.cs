using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Sharpility.Extensions;
using NodaTime;

namespace IO.Swagger.sa_mustafaucloudv1.Models
{
    /// <summary>
    /// Gallery
    /// </summary>
    public sealed class Gallery:  IEquatable<Gallery>
    { 
        /// <summary>
        /// Id
        /// </summary>
        public string Id { get; private set; }

        /// <summary>
        /// Name
        /// </summary>
        public string Name { get; private set; }

        /// <summary>
        /// Tag
        /// </summary>
        public string Tag { get; private set; }

        /// <summary>
        /// Watchlist gallreies remain in memory for identification with incoming images.
        /// </summary>
        public bool? Watchlist { get; private set; }


        /// <summary>
        /// Empty constructor required by some serializers.
        /// Use Gallery.Builder() for instance creation instead.
        /// </summary>
        [Obsolete]
        public Gallery()
        {
        }

        private Gallery(string Id, string Name, string Tag, bool? Watchlist)
        {
            
            this.Id = Id;
            
            this.Name = Name;
            
            this.Tag = Tag;
            
            this.Watchlist = Watchlist;
            
        }

        /// <summary>
        /// Returns builder of Gallery.
        /// </summary>
        /// <returns>GalleryBuilder</returns>
        public static GalleryBuilder Builder()
        {
            return new GalleryBuilder();
        }

        /// <summary>
        /// Returns GalleryBuilder with properties set.
        /// Use it to change properties.
        /// </summary>
        /// <returns>GalleryBuilder</returns>
        public GalleryBuilder With()
        {
            return Builder()
                .Id(Id)
                .Name(Name)
                .Tag(Tag)
                .Watchlist(Watchlist);
        }

        public override string ToString()
        {
            return this.PropertiesToString();
        }

        public override bool Equals(object obj)
        {
            return this.EqualsByProperties(obj);
        }

        public bool Equals(Gallery other)
        {
            return Equals((object) other);
        }

        public override int GetHashCode()
        {
            return this.PropertiesHash();
        }

        /// <summary>
        /// Implementation of == operator for (Gallery.
        /// </summary>
        /// <param name="left">Compared (Gallery</param>
        /// <param name="right">Compared (Gallery</param>
        /// <returns>true if compared items are equals, false otherwise</returns>
        public static bool operator == (Gallery left, Gallery right)
        {
            return Equals(left, right);
        }

        /// <summary>
        /// Implementation of != operator for (Gallery.
        /// </summary>
        /// <param name="left">Compared (Gallery</param>
        /// <param name="right">Compared (Gallery</param>
        /// <returns>true if compared items are not equals, false otherwise</returns>
        public static bool operator != (Gallery left, Gallery right)
        {
            return !Equals(left, right);
        }

        /// <summary>
        /// Builder of Gallery.
        /// </summary>
        public sealed class GalleryBuilder
        {
            private string _Id;
            private string _Name;
            private string _Tag;
            private bool? _Watchlist;

            internal GalleryBuilder()
            {
                SetupDefaults();
            }

            private void SetupDefaults()
            {
                _Watchlist = false;
            }

            /// <summary>
            /// Sets value for Gallery.Id property.
            /// </summary>
            /// <param name="value">Id</param>
            public GalleryBuilder Id(string value)
            {
                _Id = value;
                return this;
            }

            /// <summary>
            /// Sets value for Gallery.Name property.
            /// </summary>
            /// <param name="value">Name</param>
            public GalleryBuilder Name(string value)
            {
                _Name = value;
                return this;
            }

            /// <summary>
            /// Sets value for Gallery.Tag property.
            /// </summary>
            /// <param name="value">Tag</param>
            public GalleryBuilder Tag(string value)
            {
                _Tag = value;
                return this;
            }

            /// <summary>
            /// Sets value for Gallery.Watchlist property.
            /// </summary>
            /// <param name="value">Watchlist gallreies remain in memory for identification with incoming images.</param>
            public GalleryBuilder Watchlist(bool? value)
            {
                _Watchlist = value;
                return this;
            }


            /// <summary>
            /// Builds instance of Gallery.
            /// </summary>
            /// <returns>Gallery</returns>
            public Gallery Build()
            {
                Validate();
                return new Gallery(
                    Id: _Id,
                    Name: _Name,
                    Tag: _Tag,
                    Watchlist: _Watchlist
                );
            }

            private void Validate()
            { 
            }
        }

        
    }
}