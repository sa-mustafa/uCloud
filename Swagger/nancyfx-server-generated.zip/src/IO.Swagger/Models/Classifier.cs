using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Sharpility.Extensions;
using NodaTime;

namespace IO.Swagger.sa_mustafaucloudv1.Models
{
    /// <summary>
    /// Classifier
    /// </summary>
    public sealed class Classifier:  IEquatable<Classifier>
    { 
        /// <summary>
        /// Id
        /// </summary>
        public string Id { get; private set; }

        /// <summary>
        /// Name
        /// </summary>
        public string Name { get; private set; }

        /// <summary>
        /// Tag
        /// </summary>
        public string Tag { get; private set; }

        /// <summary>
        /// UseColorInfo
        /// </summary>
        public bool? UseColorInfo { get; private set; }

        /// <summary>
        /// UseTextureInfo
        /// </summary>
        public bool? UseTextureInfo { get; private set; }

        /// <summary>
        /// sample image resizing options
        /// </summary>
        public ResizeOptionsEnum? ResizeOptions { get; private set; }

        /// <summary>
        /// ResizeValue
        /// </summary>
        public float? ResizeValue { get; private set; }


        /// <summary>
        /// Empty constructor required by some serializers.
        /// Use Classifier.Builder() for instance creation instead.
        /// </summary>
        [Obsolete]
        public Classifier()
        {
        }

        private Classifier(string Id, string Name, string Tag, bool? UseColorInfo, bool? UseTextureInfo, ResizeOptionsEnum? ResizeOptions, float? ResizeValue)
        {
            
            this.Id = Id;
            
            this.Name = Name;
            
            this.Tag = Tag;
            
            this.UseColorInfo = UseColorInfo;
            
            this.UseTextureInfo = UseTextureInfo;
            
            this.ResizeOptions = ResizeOptions;
            
            this.ResizeValue = ResizeValue;
            
        }

        /// <summary>
        /// Returns builder of Classifier.
        /// </summary>
        /// <returns>ClassifierBuilder</returns>
        public static ClassifierBuilder Builder()
        {
            return new ClassifierBuilder();
        }

        /// <summary>
        /// Returns ClassifierBuilder with properties set.
        /// Use it to change properties.
        /// </summary>
        /// <returns>ClassifierBuilder</returns>
        public ClassifierBuilder With()
        {
            return Builder()
                .Id(Id)
                .Name(Name)
                .Tag(Tag)
                .UseColorInfo(UseColorInfo)
                .UseTextureInfo(UseTextureInfo)
                .ResizeOptions(ResizeOptions)
                .ResizeValue(ResizeValue);
        }

        public override string ToString()
        {
            return this.PropertiesToString();
        }

        public override bool Equals(object obj)
        {
            return this.EqualsByProperties(obj);
        }

        public bool Equals(Classifier other)
        {
            return Equals((object) other);
        }

        public override int GetHashCode()
        {
            return this.PropertiesHash();
        }

        /// <summary>
        /// Implementation of == operator for (Classifier.
        /// </summary>
        /// <param name="left">Compared (Classifier</param>
        /// <param name="right">Compared (Classifier</param>
        /// <returns>true if compared items are equals, false otherwise</returns>
        public static bool operator == (Classifier left, Classifier right)
        {
            return Equals(left, right);
        }

        /// <summary>
        /// Implementation of != operator for (Classifier.
        /// </summary>
        /// <param name="left">Compared (Classifier</param>
        /// <param name="right">Compared (Classifier</param>
        /// <returns>true if compared items are not equals, false otherwise</returns>
        public static bool operator != (Classifier left, Classifier right)
        {
            return !Equals(left, right);
        }

        /// <summary>
        /// Builder of Classifier.
        /// </summary>
        public sealed class ClassifierBuilder
        {
            private string _Id;
            private string _Name;
            private string _Tag;
            private bool? _UseColorInfo;
            private bool? _UseTextureInfo;
            private ResizeOptionsEnum? _ResizeOptions;
            private float? _ResizeValue;

            internal ClassifierBuilder()
            {
                SetupDefaults();
            }

            private void SetupDefaults()
            {
                _UseColorInfo = false;
                _UseTextureInfo = true;
                _ResizeOptions = ResizeOptionsEnum.ImageArea;
                _ResizeValue = 0.5F;
            }

            /// <summary>
            /// Sets value for Classifier.Id property.
            /// </summary>
            /// <param name="value">Id</param>
            public ClassifierBuilder Id(string value)
            {
                _Id = value;
                return this;
            }

            /// <summary>
            /// Sets value for Classifier.Name property.
            /// </summary>
            /// <param name="value">Name</param>
            public ClassifierBuilder Name(string value)
            {
                _Name = value;
                return this;
            }

            /// <summary>
            /// Sets value for Classifier.Tag property.
            /// </summary>
            /// <param name="value">Tag</param>
            public ClassifierBuilder Tag(string value)
            {
                _Tag = value;
                return this;
            }

            /// <summary>
            /// Sets value for Classifier.UseColorInfo property.
            /// </summary>
            /// <param name="value">UseColorInfo</param>
            public ClassifierBuilder UseColorInfo(bool? value)
            {
                _UseColorInfo = value;
                return this;
            }

            /// <summary>
            /// Sets value for Classifier.UseTextureInfo property.
            /// </summary>
            /// <param name="value">UseTextureInfo</param>
            public ClassifierBuilder UseTextureInfo(bool? value)
            {
                _UseTextureInfo = value;
                return this;
            }

            /// <summary>
            /// Sets value for Classifier.ResizeOptions property.
            /// </summary>
            /// <param name="value">sample image resizing options</param>
            public ClassifierBuilder ResizeOptions(ResizeOptionsEnum? value)
            {
                _ResizeOptions = value;
                return this;
            }

            /// <summary>
            /// Sets value for Classifier.ResizeValue property.
            /// </summary>
            /// <param name="value">ResizeValue</param>
            public ClassifierBuilder ResizeValue(float? value)
            {
                _ResizeValue = value;
                return this;
            }


            /// <summary>
            /// Builds instance of Classifier.
            /// </summary>
            /// <returns>Classifier</returns>
            public Classifier Build()
            {
                Validate();
                return new Classifier(
                    Id: _Id,
                    Name: _Name,
                    Tag: _Tag,
                    UseColorInfo: _UseColorInfo,
                    UseTextureInfo: _UseTextureInfo,
                    ResizeOptions: _ResizeOptions,
                    ResizeValue: _ResizeValue
                );
            }

            private void Validate()
            { 
            }
        }

        
        public enum ResizeOptionsEnum { None, ScaleBy, ImageArea };
    }
}