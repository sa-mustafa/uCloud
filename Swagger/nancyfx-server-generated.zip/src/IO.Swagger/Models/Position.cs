using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Sharpility.Extensions;
using NodaTime;

namespace IO.Swagger.sa_mustafaucloudv1.Models
{
    /// <summary>
    /// Position
    /// </summary>
    public sealed class Position:  IEquatable<Position>
    { 
        /// <summary>
        /// X
        /// </summary>
        public float? X { get; private set; }

        /// <summary>
        /// Y
        /// </summary>
        public float? Y { get; private set; }


        /// <summary>
        /// Empty constructor required by some serializers.
        /// Use Position.Builder() for instance creation instead.
        /// </summary>
        [Obsolete]
        public Position()
        {
        }

        private Position(float? X, float? Y)
        {
            
            this.X = X;
            
            this.Y = Y;
            
        }

        /// <summary>
        /// Returns builder of Position.
        /// </summary>
        /// <returns>PositionBuilder</returns>
        public static PositionBuilder Builder()
        {
            return new PositionBuilder();
        }

        /// <summary>
        /// Returns PositionBuilder with properties set.
        /// Use it to change properties.
        /// </summary>
        /// <returns>PositionBuilder</returns>
        public PositionBuilder With()
        {
            return Builder()
                .X(X)
                .Y(Y);
        }

        public override string ToString()
        {
            return this.PropertiesToString();
        }

        public override bool Equals(object obj)
        {
            return this.EqualsByProperties(obj);
        }

        public bool Equals(Position other)
        {
            return Equals((object) other);
        }

        public override int GetHashCode()
        {
            return this.PropertiesHash();
        }

        /// <summary>
        /// Implementation of == operator for (Position.
        /// </summary>
        /// <param name="left">Compared (Position</param>
        /// <param name="right">Compared (Position</param>
        /// <returns>true if compared items are equals, false otherwise</returns>
        public static bool operator == (Position left, Position right)
        {
            return Equals(left, right);
        }

        /// <summary>
        /// Implementation of != operator for (Position.
        /// </summary>
        /// <param name="left">Compared (Position</param>
        /// <param name="right">Compared (Position</param>
        /// <returns>true if compared items are not equals, false otherwise</returns>
        public static bool operator != (Position left, Position right)
        {
            return !Equals(left, right);
        }

        /// <summary>
        /// Builder of Position.
        /// </summary>
        public sealed class PositionBuilder
        {
            private float? _X;
            private float? _Y;

            internal PositionBuilder()
            {
                SetupDefaults();
            }

            private void SetupDefaults()
            {
            }

            /// <summary>
            /// Sets value for Position.X property.
            /// </summary>
            /// <param name="value">X</param>
            public PositionBuilder X(float? value)
            {
                _X = value;
                return this;
            }

            /// <summary>
            /// Sets value for Position.Y property.
            /// </summary>
            /// <param name="value">Y</param>
            public PositionBuilder Y(float? value)
            {
                _Y = value;
                return this;
            }


            /// <summary>
            /// Builds instance of Position.
            /// </summary>
            /// <returns>Position</returns>
            public Position Build()
            {
                Validate();
                return new Position(
                    X: _X,
                    Y: _Y
                );
            }

            private void Validate()
            { 
            }
        }

        
    }
}