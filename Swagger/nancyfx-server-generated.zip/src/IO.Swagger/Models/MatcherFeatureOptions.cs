using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Sharpility.Extensions;
using NodaTime;

namespace IO.Swagger.sa_mustafaucloudv1.Models
{
    /// <summary>
    /// select feature&#39;s options; applies only to feature matcher type.
    /// </summary>
    public sealed class MatcherFeatureOptions:  IEquatable<MatcherFeatureOptions>
    { 
        /// <summary>
        /// Deeper feature&#39;s descriptor can better discriminate object points at the cost of more memory.
        /// </summary>
        public int? Depth { get; private set; }

        /// <summary>
        /// Using more descriptors increases the matching robustness at the cost of runtime speed.
        /// </summary>
        public int? Count { get; private set; }

        /// <summary>
        /// length of a square created around a feature point for descriptor extraction
        /// </summary>
        public int? PatchSize { get; private set; }

        /// <summary>
        /// enable perspective matching. When disabled, training time can be greatly reduced while still able to recognize objects in perspective.
        /// </summary>
        public bool? Perspective { get; private set; }

        /// <summary>
        /// smallest rotation of the model in degrees
        /// </summary>
        public float? RotationMin { get; private set; }

        /// <summary>
        /// largest rotation of the model in degrees
        /// </summary>
        public float? RotationMax { get; private set; }

        /// <summary>
        /// minimal scale of the model
        /// </summary>
        public float? ScaleMin { get; private set; }

        /// <summary>
        /// maximal scale of the model
        /// </summary>
        public float? ScaleMax { get; private set; }


        /// <summary>
        /// Empty constructor required by some serializers.
        /// Use MatcherFeatureOptions.Builder() for instance creation instead.
        /// </summary>
        [Obsolete]
        public MatcherFeatureOptions()
        {
        }

        private MatcherFeatureOptions(int? Depth, int? Count, int? PatchSize, bool? Perspective, float? RotationMin, float? RotationMax, float? ScaleMin, float? ScaleMax)
        {
            
            this.Depth = Depth;
            
            this.Count = Count;
            
            this.PatchSize = PatchSize;
            
            this.Perspective = Perspective;
            
            this.RotationMin = RotationMin;
            
            this.RotationMax = RotationMax;
            
            this.ScaleMin = ScaleMin;
            
            this.ScaleMax = ScaleMax;
            
        }

        /// <summary>
        /// Returns builder of MatcherFeatureOptions.
        /// </summary>
        /// <returns>MatcherFeatureOptionsBuilder</returns>
        public static MatcherFeatureOptionsBuilder Builder()
        {
            return new MatcherFeatureOptionsBuilder();
        }

        /// <summary>
        /// Returns MatcherFeatureOptionsBuilder with properties set.
        /// Use it to change properties.
        /// </summary>
        /// <returns>MatcherFeatureOptionsBuilder</returns>
        public MatcherFeatureOptionsBuilder With()
        {
            return Builder()
                .Depth(Depth)
                .Count(Count)
                .PatchSize(PatchSize)
                .Perspective(Perspective)
                .RotationMin(RotationMin)
                .RotationMax(RotationMax)
                .ScaleMin(ScaleMin)
                .ScaleMax(ScaleMax);
        }

        public override string ToString()
        {
            return this.PropertiesToString();
        }

        public override bool Equals(object obj)
        {
            return this.EqualsByProperties(obj);
        }

        public bool Equals(MatcherFeatureOptions other)
        {
            return Equals((object) other);
        }

        public override int GetHashCode()
        {
            return this.PropertiesHash();
        }

        /// <summary>
        /// Implementation of == operator for (MatcherFeatureOptions.
        /// </summary>
        /// <param name="left">Compared (MatcherFeatureOptions</param>
        /// <param name="right">Compared (MatcherFeatureOptions</param>
        /// <returns>true if compared items are equals, false otherwise</returns>
        public static bool operator == (MatcherFeatureOptions left, MatcherFeatureOptions right)
        {
            return Equals(left, right);
        }

        /// <summary>
        /// Implementation of != operator for (MatcherFeatureOptions.
        /// </summary>
        /// <param name="left">Compared (MatcherFeatureOptions</param>
        /// <param name="right">Compared (MatcherFeatureOptions</param>
        /// <returns>true if compared items are not equals, false otherwise</returns>
        public static bool operator != (MatcherFeatureOptions left, MatcherFeatureOptions right)
        {
            return !Equals(left, right);
        }

        /// <summary>
        /// Builder of MatcherFeatureOptions.
        /// </summary>
        public sealed class MatcherFeatureOptionsBuilder
        {
            private int? _Depth;
            private int? _Count;
            private int? _PatchSize;
            private bool? _Perspective;
            private float? _RotationMin;
            private float? _RotationMax;
            private float? _ScaleMin;
            private float? _ScaleMax;

            internal MatcherFeatureOptionsBuilder()
            {
                SetupDefaults();
            }

            private void SetupDefaults()
            {
                _Perspective = true;
                _RotationMin = -180.0F;
                _RotationMax = 180.0F;
                _ScaleMin = 0.5F;
                _ScaleMax = 1.4F;
            }

            /// <summary>
            /// Sets value for MatcherFeatureOptions.Depth property.
            /// </summary>
            /// <param name="value">Deeper feature&#39;s descriptor can better discriminate object points at the cost of more memory.</param>
            public MatcherFeatureOptionsBuilder Depth(int? value)
            {
                _Depth = value;
                return this;
            }

            /// <summary>
            /// Sets value for MatcherFeatureOptions.Count property.
            /// </summary>
            /// <param name="value">Using more descriptors increases the matching robustness at the cost of runtime speed.</param>
            public MatcherFeatureOptionsBuilder Count(int? value)
            {
                _Count = value;
                return this;
            }

            /// <summary>
            /// Sets value for MatcherFeatureOptions.PatchSize property.
            /// </summary>
            /// <param name="value">length of a square created around a feature point for descriptor extraction</param>
            public MatcherFeatureOptionsBuilder PatchSize(int? value)
            {
                _PatchSize = value;
                return this;
            }

            /// <summary>
            /// Sets value for MatcherFeatureOptions.Perspective property.
            /// </summary>
            /// <param name="value">enable perspective matching. When disabled, training time can be greatly reduced while still able to recognize objects in perspective.</param>
            public MatcherFeatureOptionsBuilder Perspective(bool? value)
            {
                _Perspective = value;
                return this;
            }

            /// <summary>
            /// Sets value for MatcherFeatureOptions.RotationMin property.
            /// </summary>
            /// <param name="value">smallest rotation of the model in degrees</param>
            public MatcherFeatureOptionsBuilder RotationMin(float? value)
            {
                _RotationMin = value;
                return this;
            }

            /// <summary>
            /// Sets value for MatcherFeatureOptions.RotationMax property.
            /// </summary>
            /// <param name="value">largest rotation of the model in degrees</param>
            public MatcherFeatureOptionsBuilder RotationMax(float? value)
            {
                _RotationMax = value;
                return this;
            }

            /// <summary>
            /// Sets value for MatcherFeatureOptions.ScaleMin property.
            /// </summary>
            /// <param name="value">minimal scale of the model</param>
            public MatcherFeatureOptionsBuilder ScaleMin(float? value)
            {
                _ScaleMin = value;
                return this;
            }

            /// <summary>
            /// Sets value for MatcherFeatureOptions.ScaleMax property.
            /// </summary>
            /// <param name="value">maximal scale of the model</param>
            public MatcherFeatureOptionsBuilder ScaleMax(float? value)
            {
                _ScaleMax = value;
                return this;
            }


            /// <summary>
            /// Builds instance of MatcherFeatureOptions.
            /// </summary>
            /// <returns>MatcherFeatureOptions</returns>
            public MatcherFeatureOptions Build()
            {
                Validate();
                return new MatcherFeatureOptions(
                    Depth: _Depth,
                    Count: _Count,
                    PatchSize: _PatchSize,
                    Perspective: _Perspective,
                    RotationMin: _RotationMin,
                    RotationMax: _RotationMax,
                    ScaleMin: _ScaleMin,
                    ScaleMax: _ScaleMax
                );
            }

            private void Validate()
            { 
            }
        }

        
    }
}