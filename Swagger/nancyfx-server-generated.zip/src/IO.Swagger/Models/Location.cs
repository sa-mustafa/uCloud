using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Sharpility.Extensions;
using NodaTime;

namespace IO.Swagger.sa_mustafaucloudv1.Models
{
    /// <summary>
    /// Location
    /// </summary>
    public sealed class Location:  IEquatable<Location>
    { 
        /// <summary>
        /// Left
        /// </summary>
        public float? Left { get; private set; }

        /// <summary>
        /// Top
        /// </summary>
        public float? Top { get; private set; }

        /// <summary>
        /// Height
        /// </summary>
        public float? Height { get; private set; }

        /// <summary>
        /// Width
        /// </summary>
        public float? Width { get; private set; }


        /// <summary>
        /// Empty constructor required by some serializers.
        /// Use Location.Builder() for instance creation instead.
        /// </summary>
        [Obsolete]
        public Location()
        {
        }

        private Location(float? Left, float? Top, float? Height, float? Width)
        {
            
            this.Left = Left;
            
            this.Top = Top;
            
            this.Height = Height;
            
            this.Width = Width;
            
        }

        /// <summary>
        /// Returns builder of Location.
        /// </summary>
        /// <returns>LocationBuilder</returns>
        public static LocationBuilder Builder()
        {
            return new LocationBuilder();
        }

        /// <summary>
        /// Returns LocationBuilder with properties set.
        /// Use it to change properties.
        /// </summary>
        /// <returns>LocationBuilder</returns>
        public LocationBuilder With()
        {
            return Builder()
                .Left(Left)
                .Top(Top)
                .Height(Height)
                .Width(Width);
        }

        public override string ToString()
        {
            return this.PropertiesToString();
        }

        public override bool Equals(object obj)
        {
            return this.EqualsByProperties(obj);
        }

        public bool Equals(Location other)
        {
            return Equals((object) other);
        }

        public override int GetHashCode()
        {
            return this.PropertiesHash();
        }

        /// <summary>
        /// Implementation of == operator for (Location.
        /// </summary>
        /// <param name="left">Compared (Location</param>
        /// <param name="right">Compared (Location</param>
        /// <returns>true if compared items are equals, false otherwise</returns>
        public static bool operator == (Location left, Location right)
        {
            return Equals(left, right);
        }

        /// <summary>
        /// Implementation of != operator for (Location.
        /// </summary>
        /// <param name="left">Compared (Location</param>
        /// <param name="right">Compared (Location</param>
        /// <returns>true if compared items are not equals, false otherwise</returns>
        public static bool operator != (Location left, Location right)
        {
            return !Equals(left, right);
        }

        /// <summary>
        /// Builder of Location.
        /// </summary>
        public sealed class LocationBuilder
        {
            private float? _Left;
            private float? _Top;
            private float? _Height;
            private float? _Width;

            internal LocationBuilder()
            {
                SetupDefaults();
            }

            private void SetupDefaults()
            {
            }

            /// <summary>
            /// Sets value for Location.Left property.
            /// </summary>
            /// <param name="value">Left</param>
            public LocationBuilder Left(float? value)
            {
                _Left = value;
                return this;
            }

            /// <summary>
            /// Sets value for Location.Top property.
            /// </summary>
            /// <param name="value">Top</param>
            public LocationBuilder Top(float? value)
            {
                _Top = value;
                return this;
            }

            /// <summary>
            /// Sets value for Location.Height property.
            /// </summary>
            /// <param name="value">Height</param>
            public LocationBuilder Height(float? value)
            {
                _Height = value;
                return this;
            }

            /// <summary>
            /// Sets value for Location.Width property.
            /// </summary>
            /// <param name="value">Width</param>
            public LocationBuilder Width(float? value)
            {
                _Width = value;
                return this;
            }


            /// <summary>
            /// Builds instance of Location.
            /// </summary>
            /// <returns>Location</returns>
            public Location Build()
            {
                Validate();
                return new Location(
                    Left: _Left,
                    Top: _Top,
                    Height: _Height,
                    Width: _Width
                );
            }

            private void Validate()
            { 
            }
        }

        
    }
}