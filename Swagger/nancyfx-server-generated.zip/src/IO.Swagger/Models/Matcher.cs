using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Sharpility.Extensions;
using NodaTime;

namespace IO.Swagger.sa_mustafaucloudv1.Models
{
    /// <summary>
    /// Matcher
    /// </summary>
    public sealed class Matcher:  IEquatable<Matcher>
    { 
        /// <summary>
        /// Id
        /// </summary>
        public string Id { get; private set; }

        /// <summary>
        /// Specify the matcher type to use: * NCC: normalized cross correlation matching * Anisotropic: shape model with orientation change and independent scaling in column &amp; row directions * Isotropic: shape model with orientation change and equal scaling in column &amp; row directions * Shape: shape model matching with orientation change only * Deformable: deformable shape model with orientation change and independent scaling in column &amp; row directions * Feature: interest point matching for objects distorted by a projective view * Perspective: deformable model matching for objects distorted by a projective view 
        /// </summary>
        public TypeEnum? Type { get; private set; }

        /// <summary>
        /// smallest rotation of the pattern in degrees; applies to all matchers except feature type
        /// </summary>
        public float? AngleStart { get; private set; }

        /// <summary>
        /// extent of the rotation angle in degrees; applies to all matchers except feature type
        /// </summary>
        public float? AngleExtent { get; private set; }

        /// <summary>
        /// step length of the angles in degrees; applies to all matchers except feature type
        /// </summary>
        public float? AngleStep { get; private set; }

        /// <summary>
        /// Specify the model contrast in the template image; 3 values may be specified: lower threshold, upper threshold and minimum object size for suppressing small artifacts; applies to all matchers except NCC/feature types.
        /// </summary>
        public List<float?> Contrast { get; private set; }

        /// <summary>
        /// Specify the minimum object contrast in the search image; this value should be chosen larger the noise level in the image; applies to all matchers except NCC/feature types.
        /// </summary>
        public float? MinContrast { get; private set; }

        /// <summary>
        /// select feature type; applies only to feature matcher type.
        /// </summary>
        public FeatureTypeEnum? FeatureType { get; private set; }

        /// <summary>
        /// FeatureOptions
        /// </summary>
        public MatcherFeatureOptions FeatureOptions { get; private set; }

        /// <summary>
        /// choose optimization applied to model generation; applies to all matchers except NCC/feature types.
        /// </summary>
        public OptimizationEnum? Optimization { get; private set; }

        /// <summary>
        /// maximum number of pyramid levels; applies to all matchers except feature type
        /// </summary>
        public int? Pyramids { get; private set; }

        /// <summary>
        /// Specify whether to enforce the model polarity; applies to all matchers except feature type. * enforce: match the object accrdoing to initial model&#39;s contrast level * ignore_color: matching should ignore changes in the object color; it is not applicable to NCC type * ignore_local: matching should ignore changes in the object contrast; it is not applicable to NCC type * ignore_global: match the object even if the whole image contrast is inverted.  
        /// </summary>
        public PolarityEnum? Polarity { get; private set; }

        /// <summary>
        /// Specify the model scale variation in column(X) direction; 3 values may be specified: minimum scale, maximum scale and scale step change for model creation; applies to anisotropic/deformable/perspective types.
        /// </summary>
        public List<float?> ScaleCol { get; private set; }

        /// <summary>
        /// Specify the model scale variation in row(Y) direction; 3 values may be specified: minimum scale, maximum scale and scale step change for model creation; applies to anisotropic/deformable/perspective types.
        /// </summary>
        public List<float?> ScaleRow { get; private set; }

        /// <summary>
        /// Specify the model scale variation in; 3 values may be specified: minimum scale, maximum scale and scale step change for model creation; applies to isotropic type only.
        /// </summary>
        public List<float?> Scale { get; private set; }


        /// <summary>
        /// Empty constructor required by some serializers.
        /// Use Matcher.Builder() for instance creation instead.
        /// </summary>
        [Obsolete]
        public Matcher()
        {
        }

        private Matcher(string Id, TypeEnum? Type, float? AngleStart, float? AngleExtent, float? AngleStep, List<float?> Contrast, float? MinContrast, FeatureTypeEnum? FeatureType, MatcherFeatureOptions FeatureOptions, OptimizationEnum? Optimization, int? Pyramids, PolarityEnum? Polarity, List<float?> ScaleCol, List<float?> ScaleRow, List<float?> Scale)
        {
            
            this.Id = Id;
            
            this.Type = Type;
            
            this.AngleStart = AngleStart;
            
            this.AngleExtent = AngleExtent;
            
            this.AngleStep = AngleStep;
            
            this.Contrast = Contrast;
            
            this.MinContrast = MinContrast;
            
            this.FeatureType = FeatureType;
            
            this.FeatureOptions = FeatureOptions;
            
            this.Optimization = Optimization;
            
            this.Pyramids = Pyramids;
            
            this.Polarity = Polarity;
            
            this.ScaleCol = ScaleCol;
            
            this.ScaleRow = ScaleRow;
            
            this.Scale = Scale;
            
        }

        /// <summary>
        /// Returns builder of Matcher.
        /// </summary>
        /// <returns>MatcherBuilder</returns>
        public static MatcherBuilder Builder()
        {
            return new MatcherBuilder();
        }

        /// <summary>
        /// Returns MatcherBuilder with properties set.
        /// Use it to change properties.
        /// </summary>
        /// <returns>MatcherBuilder</returns>
        public MatcherBuilder With()
        {
            return Builder()
                .Id(Id)
                .Type(Type)
                .AngleStart(AngleStart)
                .AngleExtent(AngleExtent)
                .AngleStep(AngleStep)
                .Contrast(Contrast)
                .MinContrast(MinContrast)
                .FeatureType(FeatureType)
                .FeatureOptions(FeatureOptions)
                .Optimization(Optimization)
                .Pyramids(Pyramids)
                .Polarity(Polarity)
                .ScaleCol(ScaleCol)
                .ScaleRow(ScaleRow)
                .Scale(Scale);
        }

        public override string ToString()
        {
            return this.PropertiesToString();
        }

        public override bool Equals(object obj)
        {
            return this.EqualsByProperties(obj);
        }

        public bool Equals(Matcher other)
        {
            return Equals((object) other);
        }

        public override int GetHashCode()
        {
            return this.PropertiesHash();
        }

        /// <summary>
        /// Implementation of == operator for (Matcher.
        /// </summary>
        /// <param name="left">Compared (Matcher</param>
        /// <param name="right">Compared (Matcher</param>
        /// <returns>true if compared items are equals, false otherwise</returns>
        public static bool operator == (Matcher left, Matcher right)
        {
            return Equals(left, right);
        }

        /// <summary>
        /// Implementation of != operator for (Matcher.
        /// </summary>
        /// <param name="left">Compared (Matcher</param>
        /// <param name="right">Compared (Matcher</param>
        /// <returns>true if compared items are not equals, false otherwise</returns>
        public static bool operator != (Matcher left, Matcher right)
        {
            return !Equals(left, right);
        }

        /// <summary>
        /// Builder of Matcher.
        /// </summary>
        public sealed class MatcherBuilder
        {
            private string _Id;
            private TypeEnum? _Type;
            private float? _AngleStart;
            private float? _AngleExtent;
            private float? _AngleStep;
            private List<float?> _Contrast;
            private float? _MinContrast;
            private FeatureTypeEnum? _FeatureType;
            private MatcherFeatureOptions _FeatureOptions;
            private OptimizationEnum? _Optimization;
            private int? _Pyramids;
            private PolarityEnum? _Polarity;
            private List<float?> _ScaleCol;
            private List<float?> _ScaleRow;
            private List<float?> _Scale;

            internal MatcherBuilder()
            {
                SetupDefaults();
            }

            private void SetupDefaults()
            {
                _AngleStart = -45.0F;
                _AngleExtent = 90.0F;
                _Polarity = PolarityEnum.Enforce;
            }

            /// <summary>
            /// Sets value for Matcher.Id property.
            /// </summary>
            /// <param name="value">Id</param>
            public MatcherBuilder Id(string value)
            {
                _Id = value;
                return this;
            }

            /// <summary>
            /// Sets value for Matcher.Type property.
            /// </summary>
            /// <param name="value">Specify the matcher type to use: * NCC: normalized cross correlation matching * Anisotropic: shape model with orientation change and independent scaling in column &amp; row directions * Isotropic: shape model with orientation change and equal scaling in column &amp; row directions * Shape: shape model matching with orientation change only * Deformable: deformable shape model with orientation change and independent scaling in column &amp; row directions * Feature: interest point matching for objects distorted by a projective view * Perspective: deformable model matching for objects distorted by a projective view </param>
            public MatcherBuilder Type(TypeEnum? value)
            {
                _Type = value;
                return this;
            }

            /// <summary>
            /// Sets value for Matcher.AngleStart property.
            /// </summary>
            /// <param name="value">smallest rotation of the pattern in degrees; applies to all matchers except feature type</param>
            public MatcherBuilder AngleStart(float? value)
            {
                _AngleStart = value;
                return this;
            }

            /// <summary>
            /// Sets value for Matcher.AngleExtent property.
            /// </summary>
            /// <param name="value">extent of the rotation angle in degrees; applies to all matchers except feature type</param>
            public MatcherBuilder AngleExtent(float? value)
            {
                _AngleExtent = value;
                return this;
            }

            /// <summary>
            /// Sets value for Matcher.AngleStep property.
            /// </summary>
            /// <param name="value">step length of the angles in degrees; applies to all matchers except feature type</param>
            public MatcherBuilder AngleStep(float? value)
            {
                _AngleStep = value;
                return this;
            }

            /// <summary>
            /// Sets value for Matcher.Contrast property.
            /// </summary>
            /// <param name="value">Specify the model contrast in the template image; 3 values may be specified: lower threshold, upper threshold and minimum object size for suppressing small artifacts; applies to all matchers except NCC/feature types.</param>
            public MatcherBuilder Contrast(List<float?> value)
            {
                _Contrast = value;
                return this;
            }

            /// <summary>
            /// Sets value for Matcher.MinContrast property.
            /// </summary>
            /// <param name="value">Specify the minimum object contrast in the search image; this value should be chosen larger the noise level in the image; applies to all matchers except NCC/feature types.</param>
            public MatcherBuilder MinContrast(float? value)
            {
                _MinContrast = value;
                return this;
            }

            /// <summary>
            /// Sets value for Matcher.FeatureType property.
            /// </summary>
            /// <param name="value">select feature type; applies only to feature matcher type.</param>
            public MatcherBuilder FeatureType(FeatureTypeEnum? value)
            {
                _FeatureType = value;
                return this;
            }

            /// <summary>
            /// Sets value for Matcher.FeatureOptions property.
            /// </summary>
            /// <param name="value">FeatureOptions</param>
            public MatcherBuilder FeatureOptions(MatcherFeatureOptions value)
            {
                _FeatureOptions = value;
                return this;
            }

            /// <summary>
            /// Sets value for Matcher.Optimization property.
            /// </summary>
            /// <param name="value">choose optimization applied to model generation; applies to all matchers except NCC/feature types.</param>
            public MatcherBuilder Optimization(OptimizationEnum? value)
            {
                _Optimization = value;
                return this;
            }

            /// <summary>
            /// Sets value for Matcher.Pyramids property.
            /// </summary>
            /// <param name="value">maximum number of pyramid levels; applies to all matchers except feature type</param>
            public MatcherBuilder Pyramids(int? value)
            {
                _Pyramids = value;
                return this;
            }

            /// <summary>
            /// Sets value for Matcher.Polarity property.
            /// </summary>
            /// <param name="value">Specify whether to enforce the model polarity; applies to all matchers except feature type. * enforce: match the object accrdoing to initial model&#39;s contrast level * ignore_color: matching should ignore changes in the object color; it is not applicable to NCC type * ignore_local: matching should ignore changes in the object contrast; it is not applicable to NCC type * ignore_global: match the object even if the whole image contrast is inverted.  </param>
            public MatcherBuilder Polarity(PolarityEnum? value)
            {
                _Polarity = value;
                return this;
            }

            /// <summary>
            /// Sets value for Matcher.ScaleCol property.
            /// </summary>
            /// <param name="value">Specify the model scale variation in column(X) direction; 3 values may be specified: minimum scale, maximum scale and scale step change for model creation; applies to anisotropic/deformable/perspective types.</param>
            public MatcherBuilder ScaleCol(List<float?> value)
            {
                _ScaleCol = value;
                return this;
            }

            /// <summary>
            /// Sets value for Matcher.ScaleRow property.
            /// </summary>
            /// <param name="value">Specify the model scale variation in row(Y) direction; 3 values may be specified: minimum scale, maximum scale and scale step change for model creation; applies to anisotropic/deformable/perspective types.</param>
            public MatcherBuilder ScaleRow(List<float?> value)
            {
                _ScaleRow = value;
                return this;
            }

            /// <summary>
            /// Sets value for Matcher.Scale property.
            /// </summary>
            /// <param name="value">Specify the model scale variation in; 3 values may be specified: minimum scale, maximum scale and scale step change for model creation; applies to isotropic type only.</param>
            public MatcherBuilder Scale(List<float?> value)
            {
                _Scale = value;
                return this;
            }


            /// <summary>
            /// Builds instance of Matcher.
            /// </summary>
            /// <returns>Matcher</returns>
            public Matcher Build()
            {
                Validate();
                return new Matcher(
                    Id: _Id,
                    Type: _Type,
                    AngleStart: _AngleStart,
                    AngleExtent: _AngleExtent,
                    AngleStep: _AngleStep,
                    Contrast: _Contrast,
                    MinContrast: _MinContrast,
                    FeatureType: _FeatureType,
                    FeatureOptions: _FeatureOptions,
                    Optimization: _Optimization,
                    Pyramids: _Pyramids,
                    Polarity: _Polarity,
                    ScaleCol: _ScaleCol,
                    ScaleRow: _ScaleRow,
                    Scale: _Scale
                );
            }

            private void Validate()
            { 
                if (_Id == null)
                {
                    throw new ArgumentException("Id is a required property for Matcher and cannot be null");
                } 
                if (_Type == null)
                {
                    throw new ArgumentException("Type is a required property for Matcher and cannot be null");
                } 
            }
        }

        
        public enum TypeEnum { NCC, Anisotropic, Isotropic, Shape, Deformable, Feature, Perspective };
        public enum FeatureTypeEnum { Lepetit, Harris, HarrisBinomial };
        public enum OptimizationEnum { Auto, None, Low, Medium, High };
        public enum PolarityEnum { Enforce, IgnoreColor, IgnoreLocal, IgnoreGlobal };
    }
}