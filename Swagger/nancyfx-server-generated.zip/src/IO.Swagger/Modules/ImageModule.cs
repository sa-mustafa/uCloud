using System;
using Nancy;
using Nancy.ModelBinding;
using System.Collections.Generic;
using Sharpility.Base;
using IO.Swagger.sa_mustafaucloudv1.Models;
using IO.Swagger.sa_mustafaucloudv1.Utils;
using NodaTime;

namespace IO.Swagger.sa_mustafaucloudv1.Modules
{ 
    /// <summary>
    /// Specify the barcode type.
    /// </summary>
    public enum BarcodeCodeTypeEnum
    {
        auto = 1, 
        2/5 Industrial = 2, 
        2/5 Interleaved = 3, 
        Codabar = 4, 
        Code 128 = 5, 
        Code 39 = 6, 
        Code 93 = 7, 
        EAN-13 Add-On 2 = 8, 
        EAN-13 Add-On 5 = 9, 
        EAN-13 = 10, 
        EAN-8 Add-On 2 = 11, 
        EAN-8 Add-On 5 = 12, 
        EAN-8 = 13, 
        GS1 DataBar Expanded Stacked = 14, 
        GS1 DataBar Expanded = 15, 
        GS1 DataBar Limited = 16, 
        GS1 DataBar Omnidir = 17, 
        GS1 DataBar Stacked Omnidir = 18, 
        GS1 DataBar Stacked = 19, 
        GS1 DataBar Truncated = 20, 
        GS1-128 = 21, 
        MSI = 22, 
        PharmaCode = 23, 
        UPC-A Add-On 2 = 24, 
        UPC-A Add-On 5 = 25, 
        UPC-A = 26, 
        UPC-E Add-On 2 = 27, 
        UPC-E Add-On 5 = 28, 
        UPC-E = 29
    };

    /// <summary>
    /// Specify the barcode type.
    /// </summary>
    public enum DatacodeCodeTypeEnum
    {
        Aztec Code = 1, 
        Data Matrix ECC 200 = 2, 
        PDF417 = 3, 
        QR Code = 4, 
        Micro QR Code = 5, 
        GS1 Aztec Code = 6, 
        GS1 DataMatrix = 7, 
        GS1 QR Code = 8
    };

    /// <summary>
    /// Specify the recognition parameters.
    /// </summary>
    public enum DatacodeRecognitionEnum
    {
        standard = 1, 
        enhanced = 2, 
        maximum = 3
    };

    /// <summary>
    /// Specify Aztec model type.
    /// </summary>
    public enum DatacodeModelTypeAztecEnum
    {
        compact = 1, 
        rune = 2, 
        full_range = 3
    };

    /// <summary>
    /// Specify datacode contrast tolerance.
    /// </summary>
    public enum DatacodeContrastToleranceEnum
    {
        low = 1, 
        high = 2, 
        any = 3
    };

    /// <summary>
    /// Specify how big minimum gaps in the symbol are.
    /// </summary>
    public enum DatacodeModuleGapMinEnum
    {
        no = 1, 
        big = 2, 
        small = 3
    };

    /// <summary>
    /// Specify how big maximum gaps in the symbol are.
    /// </summary>
    public enum DatacodeModuleGapMaxEnum
    {
        no = 1, 
        big = 2, 
        small = 3
    };


    /// <summary>
    /// Module processing requests of Image domain.
    /// </summary>
    public sealed class ImageModule : NancyModule
    {
        /// <summary>
        /// Sets up HTTP methods mappings.
        /// </summary>
        /// <param name="service">Service handling requests</param>
        public ImageModule(ImageService service) : base("/sa-mustafa/ucloud/v1")
        { 
            Post["/image/barcode"] = parameters =>
            {
                var image = this.Bind<Image>();var codeType = Parameters.ValueOf<BarcodeCodeTypeEnum?>(parameters, Context.Request, "codeType", ParameterType.Query);
                var darkOnLight = Parameters.ValueOf<bool?>(parameters, Context.Request, "darkOnLight", ParameterType.Query);
                var barcodeHeightMin = Parameters.ValueOf<int?>(parameters, Context.Request, "barcodeHeightMin", ParameterType.Query);
                var barcodeWidthMin = Parameters.ValueOf<int?>(parameters, Context.Request, "barcodeWidthMin", ParameterType.Query);
                var elementSizeMin = Parameters.ValueOf<float?>(parameters, Context.Request, "elementSizeMin", ParameterType.Query);
                var elementSizeMax = Parameters.ValueOf<float?>(parameters, Context.Request, "elementSizeMax", ParameterType.Query);
                var minCodeLength = Parameters.ValueOf<decimal?>(parameters, Context.Request, "minCodeLength", ParameterType.Query);
                var minContrast = Parameters.ValueOf<decimal?>(parameters, Context.Request, "minContrast", ParameterType.Query);
                var minIdenticalScanlines = Parameters.ValueOf<int?>(parameters, Context.Request, "minIdenticalScanlines", ParameterType.Query);
                var orientation = Parameters.ValueOf<float?>(parameters, Context.Request, "orientation", ParameterType.Query);
                var orientationTolerance = Parameters.ValueOf<float?>(parameters, Context.Request, "orientationTolerance", ParameterType.Query);
                Preconditions.IsNotNull(image, "Required parameter: 'image' is missing at 'Barcode'");
                
                Preconditions.IsNotNull(codeType, "Required parameter: 'codeType' is missing at 'Barcode'");
                
                return service.Barcode(Context, image, codeType, darkOnLight, barcodeHeightMin, barcodeWidthMin, elementSizeMin, elementSizeMax, minCodeLength, minContrast, minIdenticalScanlines, orientation, orientationTolerance).ToArray();
            };

            Post["/image/datacode"] = parameters =>
            {
                var image = this.Bind<Image>();var codeType = Parameters.ValueOf<DatacodeCodeTypeEnum?>(parameters, Context.Request, "codeType", ParameterType.Query);
                var recognition = Parameters.ValueOf<DatacodeRecognitionEnum?>(parameters, Context.Request, "recognition", ParameterType.Query);
                var modelTypeAztec = Parameters.ValueOf<DatacodeModelTypeAztecEnum?>(parameters, Context.Request, "modelTypeAztec", ParameterType.Query);
                var symbolSizeMinAztec = Parameters.ValueOf<decimal?>(parameters, Context.Request, "symbolSizeMinAztec", ParameterType.Query);
                var symbolSizeMaxAztec = Parameters.ValueOf<decimal?>(parameters, Context.Request, "symbolSizeMaxAztec", ParameterType.Query);
                var symbolColsMinEcc = Parameters.ValueOf<int?>(parameters, Context.Request, "symbolColsMinEcc", ParameterType.Query);
                var symbolColsMaxEcc = Parameters.ValueOf<int?>(parameters, Context.Request, "symbolColsMaxEcc", ParameterType.Query);
                var symbolRowsMinEcc = Parameters.ValueOf<int?>(parameters, Context.Request, "symbolRowsMinEcc", ParameterType.Query);
                var symbolRowsMaxEcc = Parameters.ValueOf<int?>(parameters, Context.Request, "symbolRowsMaxEcc", ParameterType.Query);
                var modelTypeQr = Parameters.ValueOf<int?>(parameters, Context.Request, "modelTypeQr", ParameterType.Query);
                var symbolSizeMinQr = Parameters.ValueOf<decimal?>(parameters, Context.Request, "symbolSizeMinQr", ParameterType.Query);
                var symbolSizeMaxQr = Parameters.ValueOf<decimal?>(parameters, Context.Request, "symbolSizeMaxQr", ParameterType.Query);
                var symbolSizeMinUqr = Parameters.ValueOf<decimal?>(parameters, Context.Request, "symbolSizeMinUqr", ParameterType.Query);
                var symbolSizeMaxUqr = Parameters.ValueOf<decimal?>(parameters, Context.Request, "symbolSizeMaxUqr", ParameterType.Query);
                var symbolColsMinPdf = Parameters.ValueOf<decimal?>(parameters, Context.Request, "symbolColsMinPdf", ParameterType.Query);
                var symbolColsMaxPdf = Parameters.ValueOf<decimal?>(parameters, Context.Request, "symbolColsMaxPdf", ParameterType.Query);
                var symbolRowsMinPdf = Parameters.ValueOf<decimal?>(parameters, Context.Request, "symbolRowsMinPdf", ParameterType.Query);
                var symbolRowsMaxPdf = Parameters.ValueOf<decimal?>(parameters, Context.Request, "symbolRowsMaxPdf", ParameterType.Query);
                var contrastMin = Parameters.ValueOf<decimal?>(parameters, Context.Request, "contrastMin", ParameterType.Query);
                var contrastTolerance = Parameters.ValueOf<DatacodeContrastToleranceEnum?>(parameters, Context.Request, "contrastTolerance", ParameterType.Query);
                var darkOnLight = Parameters.ValueOf<bool?>(parameters, Context.Request, "darkOnLight", ParameterType.Query);
                var moduleGapMin = Parameters.ValueOf<DatacodeModuleGapMinEnum?>(parameters, Context.Request, "moduleGapMin", ParameterType.Query);
                var moduleGapMax = Parameters.ValueOf<DatacodeModuleGapMaxEnum?>(parameters, Context.Request, "moduleGapMax", ParameterType.Query);
                var slantMax = Parameters.ValueOf<float?>(parameters, Context.Request, "slantMax", ParameterType.Query);
                Preconditions.IsNotNull(image, "Required parameter: 'image' is missing at 'Datacode'");
                
                Preconditions.IsNotNull(codeType, "Required parameter: 'codeType' is missing at 'Datacode'");
                
                return service.Datacode(Context, image, codeType, recognition, modelTypeAztec, symbolSizeMinAztec, symbolSizeMaxAztec, symbolColsMinEcc, symbolColsMaxEcc, symbolRowsMinEcc, symbolRowsMaxEcc, modelTypeQr, symbolSizeMinQr, symbolSizeMaxQr, symbolSizeMinUqr, symbolSizeMaxUqr, symbolColsMinPdf, symbolColsMaxPdf, symbolRowsMinPdf, symbolRowsMaxPdf, contrastMin, contrastTolerance, darkOnLight, moduleGapMin, moduleGapMax, slantMax).ToArray();
            };
        }
    }

    /// <summary>
    /// Service handling Image requests.
    /// </summary>
    public interface ImageService
    {
        /// <summary>
        /// Detect and read barcodes found in the image.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="image">Image data for further processing</param>
        /// <param name="codeType">Specify the barcode type.</param>
        /// <param name="darkOnLight">Specify the barcode polarity. (optional, default to true)</param>
        /// <param name="barcodeHeightMin">Specify minimum barcode height. (optional, default to -1)</param>
        /// <param name="barcodeWidthMin">Specify minimum barcode width. (optional, default to -1)</param>
        /// <param name="elementSizeMin">Specify minimum element size. (optional, default to 2)</param>
        /// <param name="elementSizeMax">Specify maximum element size. (optional, default to 8)</param>
        /// <param name="minCodeLength">Specify expected minimum code length. (optional, default to 0)</param>
        /// <param name="minContrast">Specify minimum barcode contrast. (optional, default to 0)</param>
        /// <param name="minIdenticalScanlines">Specify minimum number of identical scanlines. (optional, default to 0)</param>
        /// <param name="orientation">Specify expected barcode orientation. (optional, default to 0)</param>
        /// <param name="orientationTolerance">Specify barcode orientation tolerance. (optional, default to 90)</param>
        /// <returns>List&lt;Barcode&gt;</returns>
        List<Barcode> Barcode(NancyContext context, Image image, BarcodeCodeTypeEnum? codeType, bool? darkOnLight, int? barcodeHeightMin, int? barcodeWidthMin, float? elementSizeMin, float? elementSizeMax, decimal? minCodeLength, decimal? minContrast, int? minIdenticalScanlines, float? orientation, float? orientationTolerance);

        /// <summary>
        /// Detect and read datacodes (2D barcodes) found in the image.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="image">Image data for further processing</param>
        /// <param name="codeType">Specify the barcode type.</param>
        /// <param name="recognition">Specify the recognition parameters. (optional, default to standard)</param>
        /// <param name="modelTypeAztec">Specify Aztec model type. (optional, default to compact,full_range)</param>
        /// <param name="symbolSizeMinAztec">Specify minimum symbol size for Aztec model. (optional, default to 11)</param>
        /// <param name="symbolSizeMaxAztec">Specify maximum symbol size for Aztec model. (optional, default to 151)</param>
        /// <param name="symbolColsMinEcc">Specify minimum symbol columns for ECC 200. (optional, default to 10)</param>
        /// <param name="symbolColsMaxEcc">Specify maximum symbol columns for ECC 200. (optional, default to 144)</param>
        /// <param name="symbolRowsMinEcc">Specify minimum symbol rows for ECC 200. (optional, default to 8)</param>
        /// <param name="symbolRowsMaxEcc">Specify maximum symbol rows for ECC 200. (optional, default to 144)</param>
        /// <param name="modelTypeQr">Specify QR model type. 0 means both types 1 &amp; 2. (optional, default to 0)</param>
        /// <param name="symbolSizeMinQr">Specify minimum symbol size for QR model. (optional, default to 21)</param>
        /// <param name="symbolSizeMaxQr">Specify maximum symbol size for QR model. (optional, default to 177)</param>
        /// <param name="symbolSizeMinUqr">Specify minimum symbol size for micro QR models. (optional, default to 11)</param>
        /// <param name="symbolSizeMaxUqr">Specify maximum symbol size for micro QR models. (optional, default to 17)</param>
        /// <param name="symbolColsMinPdf">Specify minimum symbol columns for PDF-417 models. (optional, default to 1)</param>
        /// <param name="symbolColsMaxPdf">Specify maximum symbol columns PDF-417 models. (optional, default to 20)</param>
        /// <param name="symbolRowsMinPdf">Specify minimum symbol rows for PDF-417 models. (optional, default to 5)</param>
        /// <param name="symbolRowsMaxPdf">Specify maximum symbol rows PDF-417 models. (optional, default to 45)</param>
        /// <param name="contrastMin">Specify minimum datacode contrast. (optional, default to 30)</param>
        /// <param name="contrastTolerance">Specify datacode contrast tolerance. (optional)</param>
        /// <param name="darkOnLight">Specify the datacode polarity. (optional, default to true)</param>
        /// <param name="moduleGapMin">Specify how big minimum gaps in the symbol are. (optional, default to no)</param>
        /// <param name="moduleGapMax">Specify how big maximum gaps in the symbol are. (optional)</param>
        /// <param name="slantMax">Specify maximum datacode slant from ideal right angle in degrees. (optional, default to 10)</param>
        /// <returns>List&lt;Barcode&gt;</returns>
        List<Barcode> Datacode(NancyContext context, Image image, DatacodeCodeTypeEnum? codeType, DatacodeRecognitionEnum? recognition, DatacodeModelTypeAztecEnum? modelTypeAztec, decimal? symbolSizeMinAztec, decimal? symbolSizeMaxAztec, int? symbolColsMinEcc, int? symbolColsMaxEcc, int? symbolRowsMinEcc, int? symbolRowsMaxEcc, int? modelTypeQr, decimal? symbolSizeMinQr, decimal? symbolSizeMaxQr, decimal? symbolSizeMinUqr, decimal? symbolSizeMaxUqr, decimal? symbolColsMinPdf, decimal? symbolColsMaxPdf, decimal? symbolRowsMinPdf, decimal? symbolRowsMaxPdf, decimal? contrastMin, DatacodeContrastToleranceEnum? contrastTolerance, bool? darkOnLight, DatacodeModuleGapMinEnum? moduleGapMin, DatacodeModuleGapMaxEnum? moduleGapMax, float? slantMax);
    }

    /// <summary>
    /// Abstraction of ImageService.
    /// </summary>
    public abstract class AbstractImageService: ImageService
    {
        public virtual List<Barcode> Barcode(NancyContext context, Image image, BarcodeCodeTypeEnum? codeType, bool? darkOnLight, int? barcodeHeightMin, int? barcodeWidthMin, float? elementSizeMin, float? elementSizeMax, decimal? minCodeLength, decimal? minContrast, int? minIdenticalScanlines, float? orientation, float? orientationTolerance)
        {
            return Barcode(image, codeType, darkOnLight, barcodeHeightMin, barcodeWidthMin, elementSizeMin, elementSizeMax, minCodeLength, minContrast, minIdenticalScanlines, orientation, orientationTolerance);
        }

        public virtual List<Barcode> Datacode(NancyContext context, Image image, DatacodeCodeTypeEnum? codeType, DatacodeRecognitionEnum? recognition, DatacodeModelTypeAztecEnum? modelTypeAztec, decimal? symbolSizeMinAztec, decimal? symbolSizeMaxAztec, int? symbolColsMinEcc, int? symbolColsMaxEcc, int? symbolRowsMinEcc, int? symbolRowsMaxEcc, int? modelTypeQr, decimal? symbolSizeMinQr, decimal? symbolSizeMaxQr, decimal? symbolSizeMinUqr, decimal? symbolSizeMaxUqr, decimal? symbolColsMinPdf, decimal? symbolColsMaxPdf, decimal? symbolRowsMinPdf, decimal? symbolRowsMaxPdf, decimal? contrastMin, DatacodeContrastToleranceEnum? contrastTolerance, bool? darkOnLight, DatacodeModuleGapMinEnum? moduleGapMin, DatacodeModuleGapMaxEnum? moduleGapMax, float? slantMax)
        {
            return Datacode(image, codeType, recognition, modelTypeAztec, symbolSizeMinAztec, symbolSizeMaxAztec, symbolColsMinEcc, symbolColsMaxEcc, symbolRowsMinEcc, symbolRowsMaxEcc, modelTypeQr, symbolSizeMinQr, symbolSizeMaxQr, symbolSizeMinUqr, symbolSizeMaxUqr, symbolColsMinPdf, symbolColsMaxPdf, symbolRowsMinPdf, symbolRowsMaxPdf, contrastMin, contrastTolerance, darkOnLight, moduleGapMin, moduleGapMax, slantMax);
        }

        protected abstract List<Barcode> Barcode(Image image, BarcodeCodeTypeEnum? codeType, bool? darkOnLight, int? barcodeHeightMin, int? barcodeWidthMin, float? elementSizeMin, float? elementSizeMax, decimal? minCodeLength, decimal? minContrast, int? minIdenticalScanlines, float? orientation, float? orientationTolerance);

        protected abstract List<Barcode> Datacode(Image image, DatacodeCodeTypeEnum? codeType, DatacodeRecognitionEnum? recognition, DatacodeModelTypeAztecEnum? modelTypeAztec, decimal? symbolSizeMinAztec, decimal? symbolSizeMaxAztec, int? symbolColsMinEcc, int? symbolColsMaxEcc, int? symbolRowsMinEcc, int? symbolRowsMaxEcc, int? modelTypeQr, decimal? symbolSizeMinQr, decimal? symbolSizeMaxQr, decimal? symbolSizeMinUqr, decimal? symbolSizeMaxUqr, decimal? symbolColsMinPdf, decimal? symbolColsMaxPdf, decimal? symbolRowsMinPdf, decimal? symbolRowsMaxPdf, decimal? contrastMin, DatacodeContrastToleranceEnum? contrastTolerance, bool? darkOnLight, DatacodeModuleGapMinEnum? moduleGapMin, DatacodeModuleGapMaxEnum? moduleGapMax, float? slantMax);
    }

}
