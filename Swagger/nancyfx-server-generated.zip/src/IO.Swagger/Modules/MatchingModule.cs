using System;
using Nancy;
using Nancy.ModelBinding;
using System.Collections.Generic;
using Sharpility.Base;
using IO.Swagger.sa_mustafaucloudv1.Models;
using IO.Swagger.sa_mustafaucloudv1.Utils;
using NodaTime;

namespace IO.Swagger.sa_mustafaucloudv1.Modules
{ 
    /// <summary>
    /// Specify model localization accuracy.
    /// </summary>
    public enum MatcherFindSubpixelEnum
    {
        none = 1, 
        interpolation = 2, 
        least_squares = 3, 
        least_squares_high = 4, 
        least_squares_very_high = 5
    };


    /// <summary>
    /// Module processing requests of Matching domain.
    /// </summary>
    public sealed class MatchingModule : NancyModule
    {
        /// <summary>
        /// Sets up HTTP methods mappings.
        /// </summary>
        /// <param name="service">Service handling requests</param>
        public MatchingModule(MatchingService service) : base("/sa-mustafa/ucloud/v1")
        { 
            Post["/matchers/{id}/find"] = parameters =>
            {
                var id = Parameters.ValueOf<string>(parameters, Context.Request, "id", ParameterType.Path);
                var image = this.Bind<Image>();var minScore = Parameters.ValueOf<float?>(parameters, Context.Request, "minScore", ParameterType.Query);
                var matchesCount = Parameters.ValueOf<int?>(parameters, Context.Request, "matchesCount", ParameterType.Query);
                var maxOverlap = Parameters.ValueOf<float?>(parameters, Context.Request, "maxOverlap", ParameterType.Query);
                var subpixel = Parameters.ValueOf<MatcherFindSubpixelEnum?>(parameters, Context.Request, "subpixel", ParameterType.Query);
                Preconditions.IsNotNull(id, "Required parameter: 'id' is missing at 'MatcherFind'");
                
                Preconditions.IsNotNull(image, "Required parameter: 'image' is missing at 'MatcherFind'");
                
                return service.MatcherFind(Context, id, image, minScore, matchesCount, maxOverlap, subpixel).ToArray();
            };

            Get["/matchers"] = parameters =>
            {
                
                return service.MatcherList(Context).ToArray();
            };

            Post["/matchers"] = parameters =>
            {
                var data = this.Bind<Matcher>();
                Preconditions.IsNotNull(data, "Required parameter: 'data' is missing at 'MatcherNew'");
                
                return service.MatcherNew(Context, data);
            };

            Delete["/matchers/{id}"] = parameters =>
            {
                var id = Parameters.ValueOf<string>(parameters, Context.Request, "id", ParameterType.Path);
                Preconditions.IsNotNull(id, "Required parameter: 'id' is missing at 'MatcherRemove'");
                
                return service.MatcherRemove(Context, id);
            };

            Put["/matchers/{id}"] = parameters =>
            {
                var id = Parameters.ValueOf<string>(parameters, Context.Request, "id", ParameterType.Path);
                var data = this.Bind<Matcher>();
                Preconditions.IsNotNull(id, "Required parameter: 'id' is missing at 'MatcherUpdate'");
                
                Preconditions.IsNotNull(data, "Required parameter: 'data' is missing at 'MatcherUpdate'");
                
                return service.MatcherUpdate(Context, id, data);
            };

            Post["/matchers/{id}"] = parameters =>
            {
                var id = Parameters.ValueOf<string>(parameters, Context.Request, "id", ParameterType.Path);
                var name = Parameters.ValueOf<string>(parameters, Context.Request, "name", ParameterType.Undefined);
                Preconditions.IsNotNull(id, "Required parameter: 'id' is missing at 'MatcherUpdateForm'");
                
                return service.MatcherUpdateForm(Context, id, name);
            };

            Get["/matchers/{id}"] = parameters =>
            {
                var id = Parameters.ValueOf<string>(parameters, Context.Request, "id", ParameterType.Path);
                Preconditions.IsNotNull(id, "Required parameter: 'id' is missing at 'MatcherView'");
                
                return service.MatcherView(Context, id);
            };
        }
    }

    /// <summary>
    /// Service handling Matching requests.
    /// </summary>
    public interface MatchingService
    {
        /// <summary>
        /// Find model instances in an image by the matcher.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="id">Matcher id to query</param>
        /// <param name="image">Image data for matching</param>
        /// <param name="minScore">Minimum match score (optional)</param>
        /// <param name="matchesCount">Maximum count of matches to return; 0 means all matches should be returned. (optional, default to 1)</param>
        /// <param name="maxOverlap">Maximum overlap of the model instances. (optional)</param>
        /// <param name="subpixel">Specify model localization accuracy. (optional)</param>
        /// <returns>List&lt;ModelInstance&gt;</returns>
        List<ModelInstance> MatcherFind(NancyContext context, string id, Image image, float? minScore, int? matchesCount, float? maxOverlap, MatcherFindSubpixelEnum? subpixel);

        /// <summary>
        /// Get the list of all matchers.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <returns>List&lt;Matcher&gt;</returns>
        List<Matcher> MatcherList(NancyContext context);

        /// <summary>
        /// Create a new matcher which can be used to find similar models in input images.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="data">Matcher for finding models</param>
        /// <returns>ApiResponse</returns>
        ApiResponse MatcherNew(NancyContext context, Matcher data);

        /// <summary>
        /// Delete a matcher by id.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="id">Matcher id to delete</param>
        /// <returns>ApiResponse</returns>
        ApiResponse MatcherRemove(NancyContext context, string id);

        /// <summary>
        /// Update a matcher.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="id">Matcher id to query</param>
        /// <param name="data">Updated matcher data</param>
        /// <returns>ApiResponse</returns>
        ApiResponse MatcherUpdate(NancyContext context, string id, Matcher data);

        /// <summary>
        /// Update a matcher with form data.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="id">Matcher id to query</param>
        /// <param name="name">Updated matcher data (optional)</param>
        /// <returns>ApiResponse</returns>
        ApiResponse MatcherUpdateForm(NancyContext context, string id, string name);

        /// <summary>
        /// View a matcher by id.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="id">Matcher id to query</param>
        /// <returns>Matcher</returns>
        Matcher MatcherView(NancyContext context, string id);
    }

    /// <summary>
    /// Abstraction of MatchingService.
    /// </summary>
    public abstract class AbstractMatchingService: MatchingService
    {
        public virtual List<ModelInstance> MatcherFind(NancyContext context, string id, Image image, float? minScore, int? matchesCount, float? maxOverlap, MatcherFindSubpixelEnum? subpixel)
        {
            return MatcherFind(id, image, minScore, matchesCount, maxOverlap, subpixel);
        }

        public virtual List<Matcher> MatcherList(NancyContext context)
        {
            return MatcherList();
        }

        public virtual ApiResponse MatcherNew(NancyContext context, Matcher data)
        {
            return MatcherNew(data);
        }

        public virtual ApiResponse MatcherRemove(NancyContext context, string id)
        {
            return MatcherRemove(id);
        }

        public virtual ApiResponse MatcherUpdate(NancyContext context, string id, Matcher data)
        {
            return MatcherUpdate(id, data);
        }

        public virtual ApiResponse MatcherUpdateForm(NancyContext context, string id, string name)
        {
            return MatcherUpdateForm(id, name);
        }

        public virtual Matcher MatcherView(NancyContext context, string id)
        {
            return MatcherView(id);
        }

        protected abstract List<ModelInstance> MatcherFind(string id, Image image, float? minScore, int? matchesCount, float? maxOverlap, MatcherFindSubpixelEnum? subpixel);

        protected abstract List<Matcher> MatcherList();

        protected abstract ApiResponse MatcherNew(Matcher data);

        protected abstract ApiResponse MatcherRemove(string id);

        protected abstract ApiResponse MatcherUpdate(string id, Matcher data);

        protected abstract ApiResponse MatcherUpdateForm(string id, string name);

        protected abstract Matcher MatcherView(string id);
    }

}
