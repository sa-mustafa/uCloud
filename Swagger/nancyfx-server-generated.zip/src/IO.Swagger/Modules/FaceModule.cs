using System;
using Nancy;
using Nancy.ModelBinding;
using System.Collections.Generic;
using Sharpility.Base;
using IO.Swagger.sa_mustafaucloudv1.Models;
using IO.Swagger.sa_mustafaucloudv1.Utils;
using NodaTime;

namespace IO.Swagger.sa_mustafaucloudv1.Modules
{ 

    /// <summary>
    /// Module processing requests of Face domain.
    /// </summary>
    public sealed class FaceModule : NancyModule
    {
        /// <summary>
        /// Sets up HTTP methods mappings.
        /// </summary>
        /// <param name="service">Service handling requests</param>
        public FaceModule(FaceService service) : base("/sa-mustafa/ucloud/v1")
        { 
            Get["/gallery/find"] = parameters =>
            {
                var tags = Parameters.ValueOf<List<string>>(parameters, Context.Request, "tags", ParameterType.Query);
                Preconditions.IsNotNull(tags, "Required parameter: 'tags' is missing at 'GalleryFind'");
                
                return service.GalleryFind(Context, tags).ToArray();
            };

            Post["/gallery/{id}/identify"] = parameters =>
            {
                var id = Parameters.ValueOf<string>(parameters, Context.Request, "id", ParameterType.Path);
                Preconditions.IsNotNull(id, "Required parameter: 'id' is missing at 'GalleryIdentify'");
                
                return service.GalleryIdentify(Context, id).ToArray();
            };

            Get["/gallery"] = parameters =>
            {
                
                return service.GalleryList(Context).ToArray();
            };

            Post["/gallery"] = parameters =>
            {
                var data = this.Bind<Gallery>();
                Preconditions.IsNotNull(data, "Required parameter: 'data' is missing at 'GalleryNew'");
                
                return service.GalleryNew(Context, data);
            };

            Delete["/gallery/{id}"] = parameters =>
            {
                var id = Parameters.ValueOf<string>(parameters, Context.Request, "id", ParameterType.Path);
                Preconditions.IsNotNull(id, "Required parameter: 'id' is missing at 'GalleryRemove'");
                
                return service.GalleryRemove(Context, id);
            };

            Put["/gallery/{id}"] = parameters =>
            {
                var id = Parameters.ValueOf<string>(parameters, Context.Request, "id", ParameterType.Path);
                var data = this.Bind<Gallery>();
                Preconditions.IsNotNull(id, "Required parameter: 'id' is missing at 'GalleryUpdate'");
                
                Preconditions.IsNotNull(data, "Required parameter: 'data' is missing at 'GalleryUpdate'");
                
                return service.GalleryUpdate(Context, id, data);
            };

            Post["/gallery/{id}"] = parameters =>
            {
                var id = Parameters.ValueOf<string>(parameters, Context.Request, "id", ParameterType.Path);
                var name = Parameters.ValueOf<string>(parameters, Context.Request, "name", ParameterType.Undefined);
                Preconditions.IsNotNull(id, "Required parameter: 'id' is missing at 'GalleryUpdateForm'");
                
                return service.GalleryUpdateForm(Context, id, name);
            };

            Get["/gallery/{id}"] = parameters =>
            {
                var id = Parameters.ValueOf<string>(parameters, Context.Request, "id", ParameterType.Path);
                Preconditions.IsNotNull(id, "Required parameter: 'id' is missing at 'GalleryView'");
                
                return service.GalleryView(Context, id);
            };

            Get["/gallery/{id}/images"] = parameters =>
            {
                var id = Parameters.ValueOf<string>(parameters, Context.Request, "id", ParameterType.Path);
                Preconditions.IsNotNull(id, "Required parameter: 'id' is missing at 'ImagesList'");
                
                return service.ImagesList(Context, id).ToArray();
            };

            Post["/gallery/{id}/images"] = parameters =>
            {
                var id = Parameters.ValueOf<string>(parameters, Context.Request, "id", ParameterType.Path);
                var image = this.Bind<Image>();
                Preconditions.IsNotNull(id, "Required parameter: 'id' is missing at 'ImagesNew'");
                
                Preconditions.IsNotNull(image, "Required parameter: 'image' is missing at 'ImagesNew'");
                
                return service.ImagesNew(Context, id, image);
            };

            Delete["/gallery/{id}/images/{imageId}"] = parameters =>
            {
                var id = Parameters.ValueOf<string>(parameters, Context.Request, "id", ParameterType.Path);
                var imageId = Parameters.ValueOf<string>(parameters, Context.Request, "imageId", ParameterType.Path);
                Preconditions.IsNotNull(id, "Required parameter: 'id' is missing at 'ImagesRemove'");
                
                Preconditions.IsNotNull(imageId, "Required parameter: 'imageId' is missing at 'ImagesRemove'");
                
                return service.ImagesRemove(Context, id, imageId);
            };

            Put["/gallery/{id}/images/{imageId}"] = parameters =>
            {
                var id = Parameters.ValueOf<string>(parameters, Context.Request, "id", ParameterType.Path);
                var imageId = Parameters.ValueOf<string>(parameters, Context.Request, "imageId", ParameterType.Path);
                var image = this.Bind<Image>();
                Preconditions.IsNotNull(id, "Required parameter: 'id' is missing at 'ImagesUpdate'");
                
                Preconditions.IsNotNull(imageId, "Required parameter: 'imageId' is missing at 'ImagesUpdate'");
                
                Preconditions.IsNotNull(image, "Required parameter: 'image' is missing at 'ImagesUpdate'");
                
                return service.ImagesUpdate(Context, id, imageId, image);
            };

            Post["/gallery/{id}/images/{imageId}"] = parameters =>
            {
                var id = Parameters.ValueOf<string>(parameters, Context.Request, "id", ParameterType.Path);
                var imageId = Parameters.ValueOf<string>(parameters, Context.Request, "imageId", ParameterType.Path);
                var name = Parameters.ValueOf<string>(parameters, Context.Request, "name", ParameterType.Undefined);
                Preconditions.IsNotNull(id, "Required parameter: 'id' is missing at 'ImagesUpdatePost'");
                
                Preconditions.IsNotNull(imageId, "Required parameter: 'imageId' is missing at 'ImagesUpdatePost'");
                
                Preconditions.IsNotNull(name, "Required parameter: 'name' is missing at 'ImagesUpdatePost'");
                
                return service.ImagesUpdatePost(Context, id, imageId, name);
            };

            Get["/gallery/{id}/images/{imageId}"] = parameters =>
            {
                var id = Parameters.ValueOf<string>(parameters, Context.Request, "id", ParameterType.Path);
                var imageId = Parameters.ValueOf<string>(parameters, Context.Request, "imageId", ParameterType.Path);
                Preconditions.IsNotNull(id, "Required parameter: 'id' is missing at 'ImagesView'");
                
                Preconditions.IsNotNull(imageId, "Required parameter: 'imageId' is missing at 'ImagesView'");
                
                return service.ImagesView(Context, id, imageId);
            };
        }
    }

    /// <summary>
    /// Service handling Face requests.
    /// </summary>
    public interface FaceService
    {
        /// <summary>
        /// Multiple tags can be provided with comma separated strings. Use tag1,tag2,tag3 for testing.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="tags">Tags to filter by</param>
        /// <returns>List&lt;Gallery&gt;</returns>
        List<Gallery> GalleryFind(NancyContext context, List<string> tags);

        /// <summary>
        /// Identify an image in the gallery.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="id">Gallery id to query</param>
        /// <returns>List&lt;Image&gt;</returns>
        List<Image> GalleryIdentify(NancyContext context, string id);

        /// <summary>
        /// Get the list of all galleries.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <returns>List&lt;Gallery&gt;</returns>
        List<Gallery> GalleryList(NancyContext context);

        /// <summary>
        /// Create a new gallery where you can logically group several images.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="data">Gallery for keeping images</param>
        /// <returns>ApiResponse</returns>
        ApiResponse GalleryNew(NancyContext context, Gallery data);

        /// <summary>
        /// Delete a gallery by id.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="id">Gallery id to delete</param>
        /// <returns>ApiResponse</returns>
        ApiResponse GalleryRemove(NancyContext context, string id);

        /// <summary>
        /// Update a gallery.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="id">Gallery id to query</param>
        /// <param name="data">Updated gallery data</param>
        /// <returns>ApiResponse</returns>
        ApiResponse GalleryUpdate(NancyContext context, string id, Gallery data);

        /// <summary>
        /// Update a gallery with form data.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="id">Gallery id to query</param>
        /// <param name="name">Updated gallery data (optional)</param>
        /// <returns>ApiResponse</returns>
        ApiResponse GalleryUpdateForm(NancyContext context, string id, string name);

        /// <summary>
        /// View a gallery by id.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="id">Gallery id to query</param>
        /// <returns>ApiResponse</returns>
        ApiResponse GalleryView(NancyContext context, string id);

        /// <summary>
        /// Get the list of images in a gallery.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="id">Gallery id to query</param>
        /// <returns>List&lt;Image&gt;</returns>
        List<Image> ImagesList(NancyContext context, string id);

        /// <summary>
        /// Create a new image and enroll it into a gallery.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="id">Gallery id to query</param>
        /// <param name="image">Image data for enrollment</param>
        /// <returns>ApiResponse</returns>
        ApiResponse ImagesNew(NancyContext context, string id, Image image);

        /// <summary>
        /// Delete an image by id.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="id">Gallery id to query</param>
        /// <param name="imageId">Image id to delete</param>
        /// <returns>ApiResponse</returns>
        ApiResponse ImagesRemove(NancyContext context, string id, string imageId);

        /// <summary>
        /// Update an image in a gallery.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="id">Gallery id to query</param>
        /// <param name="imageId">Image id to update</param>
        /// <param name="image">Updated image data</param>
        /// <returns>ApiResponse</returns>
        ApiResponse ImagesUpdate(NancyContext context, string id, string imageId, Image image);

        /// <summary>
        /// Update an image in a gallery with form data.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="id">Gallery id to query</param>
        /// <param name="imageId">Image id to update</param>
        /// <param name="name">Updated image data</param>
        /// <returns>ApiResponse</returns>
        ApiResponse ImagesUpdatePost(NancyContext context, string id, string imageId, string name);

        /// <summary>
        /// View an image in a gallery. Only a thumbnail is stored on the server.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="id">Gallery id to query</param>
        /// <param name="imageId">Image id to view</param>
        /// <returns>Image</returns>
        Image ImagesView(NancyContext context, string id, string imageId);
    }

    /// <summary>
    /// Abstraction of FaceService.
    /// </summary>
    public abstract class AbstractFaceService: FaceService
    {
        public virtual List<Gallery> GalleryFind(NancyContext context, List<string> tags)
        {
            return GalleryFind(tags);
        }

        public virtual List<Image> GalleryIdentify(NancyContext context, string id)
        {
            return GalleryIdentify(id);
        }

        public virtual List<Gallery> GalleryList(NancyContext context)
        {
            return GalleryList();
        }

        public virtual ApiResponse GalleryNew(NancyContext context, Gallery data)
        {
            return GalleryNew(data);
        }

        public virtual ApiResponse GalleryRemove(NancyContext context, string id)
        {
            return GalleryRemove(id);
        }

        public virtual ApiResponse GalleryUpdate(NancyContext context, string id, Gallery data)
        {
            return GalleryUpdate(id, data);
        }

        public virtual ApiResponse GalleryUpdateForm(NancyContext context, string id, string name)
        {
            return GalleryUpdateForm(id, name);
        }

        public virtual ApiResponse GalleryView(NancyContext context, string id)
        {
            return GalleryView(id);
        }

        public virtual List<Image> ImagesList(NancyContext context, string id)
        {
            return ImagesList(id);
        }

        public virtual ApiResponse ImagesNew(NancyContext context, string id, Image image)
        {
            return ImagesNew(id, image);
        }

        public virtual ApiResponse ImagesRemove(NancyContext context, string id, string imageId)
        {
            return ImagesRemove(id, imageId);
        }

        public virtual ApiResponse ImagesUpdate(NancyContext context, string id, string imageId, Image image)
        {
            return ImagesUpdate(id, imageId, image);
        }

        public virtual ApiResponse ImagesUpdatePost(NancyContext context, string id, string imageId, string name)
        {
            return ImagesUpdatePost(id, imageId, name);
        }

        public virtual Image ImagesView(NancyContext context, string id, string imageId)
        {
            return ImagesView(id, imageId);
        }

        protected abstract List<Gallery> GalleryFind(List<string> tags);

        protected abstract List<Image> GalleryIdentify(string id);

        protected abstract List<Gallery> GalleryList();

        protected abstract ApiResponse GalleryNew(Gallery data);

        protected abstract ApiResponse GalleryRemove(string id);

        protected abstract ApiResponse GalleryUpdate(string id, Gallery data);

        protected abstract ApiResponse GalleryUpdateForm(string id, string name);

        protected abstract ApiResponse GalleryView(string id);

        protected abstract List<Image> ImagesList(string id);

        protected abstract ApiResponse ImagesNew(string id, Image image);

        protected abstract ApiResponse ImagesRemove(string id, string imageId);

        protected abstract ApiResponse ImagesUpdate(string id, string imageId, Image image);

        protected abstract ApiResponse ImagesUpdatePost(string id, string imageId, string name);

        protected abstract Image ImagesView(string id, string imageId);
    }

}
