using System;
using Nancy;
using Nancy.ModelBinding;
using System.Collections.Generic;
using Sharpility.Base;
using IO.Swagger.sa_mustafaucloudv1.Models;
using IO.Swagger.sa_mustafaucloudv1.Utils;
using NodaTime;

namespace IO.Swagger.sa_mustafaucloudv1.Modules
{ 

    /// <summary>
    /// Module processing requests of Classifier domain.
    /// </summary>
    public sealed class ClassifierModule : NancyModule
    {
        /// <summary>
        /// Sets up HTTP methods mappings.
        /// </summary>
        /// <param name="service">Service handling requests</param>
        public ClassifierModule(ClassifierService service) : base("/sa-mustafa/ucloud/v1")
        { 
            Post["/classifiers/{id}/identify"] = parameters =>
            {
                var id = Parameters.ValueOf<string>(parameters, Context.Request, "id", ParameterType.Path);
                var image = this.Bind<Image>();
                Preconditions.IsNotNull(id, "Required parameter: 'id' is missing at 'ClassifierIdentify'");
                
                Preconditions.IsNotNull(image, "Required parameter: 'image' is missing at 'ClassifierIdentify'");
                
                return service.ClassifierIdentify(Context, id, image);
            };

            Post["/classifiers/{id}/image"] = parameters =>
            {
                var id = Parameters.ValueOf<string>(parameters, Context.Request, "id", ParameterType.Path);
                var image = this.Bind<Image>();var index = Parameters.ValueOf<decimal?>(parameters, Context.Request, "index", ParameterType.Query);
                var name = Parameters.ValueOf<string>(parameters, Context.Request, "name", ParameterType.Query);
                Preconditions.IsNotNull(id, "Required parameter: 'id' is missing at 'ClassifierImageNew'");
                
                Preconditions.IsNotNull(image, "Required parameter: 'image' is missing at 'ClassifierImageNew'");
                
                Preconditions.IsNotNull(index, "Required parameter: 'index' is missing at 'ClassifierImageNew'");
                
                return service.ClassifierImageNew(Context, id, image, index, name);
            };

            Delete["/classifiers/{id}/image/{imageId}"] = parameters =>
            {
                var id = Parameters.ValueOf<string>(parameters, Context.Request, "id", ParameterType.Path);
                var imageId = Parameters.ValueOf<string>(parameters, Context.Request, "imageId", ParameterType.Path);
                Preconditions.IsNotNull(id, "Required parameter: 'id' is missing at 'ClassifierImageRemove'");
                
                Preconditions.IsNotNull(imageId, "Required parameter: 'imageId' is missing at 'ClassifierImageRemove'");
                
                return service.ClassifierImageRemove(Context, id, imageId);
            };

            Put["/classifiers/{id}/image/{imageId}"] = parameters =>
            {
                var id = Parameters.ValueOf<string>(parameters, Context.Request, "id", ParameterType.Path);
                var imageId = Parameters.ValueOf<string>(parameters, Context.Request, "imageId", ParameterType.Path);
                var image = this.Bind<SampleImage>();
                Preconditions.IsNotNull(id, "Required parameter: 'id' is missing at 'ClassifierImageUpdate'");
                
                Preconditions.IsNotNull(imageId, "Required parameter: 'imageId' is missing at 'ClassifierImageUpdate'");
                
                Preconditions.IsNotNull(image, "Required parameter: 'image' is missing at 'ClassifierImageUpdate'");
                
                return service.ClassifierImageUpdate(Context, id, imageId, image);
            };

            Post["/classifiers/{id}/image/{imageId}"] = parameters =>
            {
                var id = Parameters.ValueOf<string>(parameters, Context.Request, "id", ParameterType.Path);
                var imageId = Parameters.ValueOf<string>(parameters, Context.Request, "imageId", ParameterType.Path);
                var name = Parameters.ValueOf<string>(parameters, Context.Request, "name", ParameterType.Undefined);
                Preconditions.IsNotNull(id, "Required parameter: 'id' is missing at 'ClassifierImageUpdatePost'");
                
                Preconditions.IsNotNull(imageId, "Required parameter: 'imageId' is missing at 'ClassifierImageUpdatePost'");
                
                Preconditions.IsNotNull(name, "Required parameter: 'name' is missing at 'ClassifierImageUpdatePost'");
                
                return service.ClassifierImageUpdatePost(Context, id, imageId, name);
            };

            Get["/classifiers/{id}/image/{imageId}"] = parameters =>
            {
                var id = Parameters.ValueOf<string>(parameters, Context.Request, "id", ParameterType.Path);
                var imageId = Parameters.ValueOf<string>(parameters, Context.Request, "imageId", ParameterType.Path);
                Preconditions.IsNotNull(id, "Required parameter: 'id' is missing at 'ClassifierImageView'");
                
                Preconditions.IsNotNull(imageId, "Required parameter: 'imageId' is missing at 'ClassifierImageView'");
                
                return service.ClassifierImageView(Context, id, imageId);
            };

            Get["/classifiers"] = parameters =>
            {
                
                return service.ClassifierList(Context).ToArray();
            };

            Post["/classifiers"] = parameters =>
            {
                var data = this.Bind<Classifier>();
                Preconditions.IsNotNull(data, "Required parameter: 'data' is missing at 'ClassifierNew'");
                
                return service.ClassifierNew(Context, data);
            };

            Delete["/classifiers/{id}"] = parameters =>
            {
                var id = Parameters.ValueOf<string>(parameters, Context.Request, "id", ParameterType.Path);
                Preconditions.IsNotNull(id, "Required parameter: 'id' is missing at 'ClassifierRemove'");
                
                return service.ClassifierRemove(Context, id);
            };

            Post["/classifiers/{id}/train"] = parameters =>
            {
                var id = Parameters.ValueOf<string>(parameters, Context.Request, "id", ParameterType.Path);
                Preconditions.IsNotNull(id, "Required parameter: 'id' is missing at 'ClassifierTrain'");
                
                return service.ClassifierTrain(Context, id);
            };

            Put["/classifiers/{id}"] = parameters =>
            {
                var id = Parameters.ValueOf<string>(parameters, Context.Request, "id", ParameterType.Path);
                var data = this.Bind<Classifier>();
                Preconditions.IsNotNull(id, "Required parameter: 'id' is missing at 'ClassifierUpdate'");
                
                Preconditions.IsNotNull(data, "Required parameter: 'data' is missing at 'ClassifierUpdate'");
                
                return service.ClassifierUpdate(Context, id, data);
            };

            Post["/classifiers/{id}"] = parameters =>
            {
                var id = Parameters.ValueOf<string>(parameters, Context.Request, "id", ParameterType.Path);
                var name = Parameters.ValueOf<string>(parameters, Context.Request, "name", ParameterType.Undefined);
                Preconditions.IsNotNull(id, "Required parameter: 'id' is missing at 'ClassifierUpdateForm'");
                
                return service.ClassifierUpdateForm(Context, id, name);
            };

            Get["/classifiers/{id}"] = parameters =>
            {
                var id = Parameters.ValueOf<string>(parameters, Context.Request, "id", ParameterType.Path);
                Preconditions.IsNotNull(id, "Required parameter: 'id' is missing at 'ClassifierView'");
                
                return service.ClassifierView(Context, id);
            };
        }
    }

    /// <summary>
    /// Service handling Classifier requests.
    /// </summary>
    public interface ClassifierService
    {
        /// <summary>
        /// Identify an image by a trained classifier.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="id">Classifier id to query</param>
        /// <param name="image">Image data for identification</param>
        /// <returns>SampleImage</returns>
        SampleImage ClassifierIdentify(NancyContext context, string id, Image image);

        /// <summary>
        /// Add a new image to classifier. Classifier uses these images for training. Multiple images of the same object should be added for enhanced results.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="id">Classifier id to query</param>
        /// <param name="image">Image data for feature extraction</param>
        /// <param name="index">Sample image index. Use multiple images with the same index and name for robustness.</param>
        /// <param name="name">Sample image name (optional)</param>
        /// <returns>ApiResponse</returns>
        ApiResponse ClassifierImageNew(NancyContext context, string id, Image image, decimal? index, string name);

        /// <summary>
        /// Delete an image by index.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="id">Classifier id to query</param>
        /// <param name="imageId">Image index to delete</param>
        /// <returns>ApiResponse</returns>
        ApiResponse ClassifierImageRemove(NancyContext context, string id, string imageId);

        /// <summary>
        /// Update image info in a classifier.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="id">Classifier id to query</param>
        /// <param name="imageId">Image index to update</param>
        /// <param name="image">Updated image data</param>
        /// <returns>ApiResponse</returns>
        ApiResponse ClassifierImageUpdate(NancyContext context, string id, string imageId, SampleImage image);

        /// <summary>
        /// Update an image in a classifier with form data.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="id">Classifier id to query</param>
        /// <param name="imageId">Image index to update</param>
        /// <param name="name">Updated image data</param>
        /// <returns>ApiResponse</returns>
        ApiResponse ClassifierImageUpdatePost(NancyContext context, string id, string imageId, string name);

        /// <summary>
        /// View an image info in a classifier.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="id">Classifier id to query</param>
        /// <param name="imageId">Image index to view</param>
        /// <returns>SampleImage</returns>
        SampleImage ClassifierImageView(NancyContext context, string id, string imageId);

        /// <summary>
        /// Get the list of all classifiers.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <returns>List&lt;Classifier&gt;</returns>
        List<Classifier> ClassifierList(NancyContext context);

        /// <summary>
        /// Create a new classifier which identifies input images into known classes.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="data">Classifier for identifying images</param>
        /// <returns>ApiResponse</returns>
        ApiResponse ClassifierNew(NancyContext context, Classifier data);

        /// <summary>
        /// Delete a classifier by id.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="id">Classifier id to delete</param>
        /// <returns>ApiResponse</returns>
        ApiResponse ClassifierRemove(NancyContext context, string id);

        /// <summary>
        /// Train classifier using sample images provided to the classifier.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="id">Classifier id to query</param>
        /// <returns>ApiResponse</returns>
        ApiResponse ClassifierTrain(NancyContext context, string id);

        /// <summary>
        /// Update a classifier.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="id">Classifier id to query</param>
        /// <param name="data">Updated classifier data</param>
        /// <returns>ApiResponse</returns>
        ApiResponse ClassifierUpdate(NancyContext context, string id, Classifier data);

        /// <summary>
        /// Update a classifier with form data.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="id">Classifier id to query</param>
        /// <param name="name">Updated classifier data (optional)</param>
        /// <returns>ApiResponse</returns>
        ApiResponse ClassifierUpdateForm(NancyContext context, string id, string name);

        /// <summary>
        /// View a classifier by id.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <param name="id">Classifier id to query</param>
        /// <returns>Classifier</returns>
        Classifier ClassifierView(NancyContext context, string id);
    }

    /// <summary>
    /// Abstraction of ClassifierService.
    /// </summary>
    public abstract class AbstractClassifierService: ClassifierService
    {
        public virtual SampleImage ClassifierIdentify(NancyContext context, string id, Image image)
        {
            return ClassifierIdentify(id, image);
        }

        public virtual ApiResponse ClassifierImageNew(NancyContext context, string id, Image image, decimal? index, string name)
        {
            return ClassifierImageNew(id, image, index, name);
        }

        public virtual ApiResponse ClassifierImageRemove(NancyContext context, string id, string imageId)
        {
            return ClassifierImageRemove(id, imageId);
        }

        public virtual ApiResponse ClassifierImageUpdate(NancyContext context, string id, string imageId, SampleImage image)
        {
            return ClassifierImageUpdate(id, imageId, image);
        }

        public virtual ApiResponse ClassifierImageUpdatePost(NancyContext context, string id, string imageId, string name)
        {
            return ClassifierImageUpdatePost(id, imageId, name);
        }

        public virtual SampleImage ClassifierImageView(NancyContext context, string id, string imageId)
        {
            return ClassifierImageView(id, imageId);
        }

        public virtual List<Classifier> ClassifierList(NancyContext context)
        {
            return ClassifierList();
        }

        public virtual ApiResponse ClassifierNew(NancyContext context, Classifier data)
        {
            return ClassifierNew(data);
        }

        public virtual ApiResponse ClassifierRemove(NancyContext context, string id)
        {
            return ClassifierRemove(id);
        }

        public virtual ApiResponse ClassifierTrain(NancyContext context, string id)
        {
            return ClassifierTrain(id);
        }

        public virtual ApiResponse ClassifierUpdate(NancyContext context, string id, Classifier data)
        {
            return ClassifierUpdate(id, data);
        }

        public virtual ApiResponse ClassifierUpdateForm(NancyContext context, string id, string name)
        {
            return ClassifierUpdateForm(id, name);
        }

        public virtual Classifier ClassifierView(NancyContext context, string id)
        {
            return ClassifierView(id);
        }

        protected abstract SampleImage ClassifierIdentify(string id, Image image);

        protected abstract ApiResponse ClassifierImageNew(string id, Image image, decimal? index, string name);

        protected abstract ApiResponse ClassifierImageRemove(string id, string imageId);

        protected abstract ApiResponse ClassifierImageUpdate(string id, string imageId, SampleImage image);

        protected abstract ApiResponse ClassifierImageUpdatePost(string id, string imageId, string name);

        protected abstract SampleImage ClassifierImageView(string id, string imageId);

        protected abstract List<Classifier> ClassifierList();

        protected abstract ApiResponse ClassifierNew(Classifier data);

        protected abstract ApiResponse ClassifierRemove(string id);

        protected abstract ApiResponse ClassifierTrain(string id);

        protected abstract ApiResponse ClassifierUpdate(string id, Classifier data);

        protected abstract ApiResponse ClassifierUpdateForm(string id, string name);

        protected abstract Classifier ClassifierView(string id);
    }

}
