using System;
using Nancy;
using Nancy.ModelBinding;
using System.Collections.Generic;
using Sharpility.Base;
using IO.Swagger.sa_mustafaucloudv1.Models;
using IO.Swagger.sa_mustafaucloudv1.Utils;
using NodaTime;

namespace IO.Swagger.sa_mustafaucloudv1.Modules
{ 

    /// <summary>
    /// Module processing requests of Default domain.
    /// </summary>
    public sealed class DefaultModule : NancyModule
    {
        /// <summary>
        /// Sets up HTTP methods mappings.
        /// </summary>
        /// <param name="service">Service handling requests</param>
        public DefaultModule(DefaultService service) : base("/sa-mustafa/ucloud/v1")
        { 
            Get["/logo"] = parameters =>
            {
                
                return service.LogoGet(Context);
            };

            Get["/ping"] = parameters =>
            {
                
                service.PingGet(Context);
                return new Response { ContentType = ""};
            };
        }
    }

    /// <summary>
    /// Service handling Default requests.
    /// </summary>
    public interface DefaultService
    {
        /// <summary>
        /// Returns the logo image
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <returns>System.IO.Stream</returns>
        System.IO.Stream LogoGet(NancyContext context);

        /// <summary>
        /// This operation shows how to override the global security defined above, as we want to open it up for all users.
        /// </summary>
        /// <param name="context">Context of request</param>
        /// <returns></returns>
        void PingGet(NancyContext context);
    }

    /// <summary>
    /// Abstraction of DefaultService.
    /// </summary>
    public abstract class AbstractDefaultService: DefaultService
    {
        public virtual System.IO.Stream LogoGet(NancyContext context)
        {
            return LogoGet();
        }

        public virtual void PingGet(NancyContext context)
        {
            PingGet();
        }

        protected abstract System.IO.Stream LogoGet();

        protected abstract void PingGet();
    }

}
